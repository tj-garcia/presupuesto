<?php 
/**
* 
SELECT ayudas.id_ayudas, beneficiario.nombres, categorias.deno_cat, ayudas.estat_ayud
FROM ayudas
INNER JOIN beneficiario ON ayudas.id=beneficiario.id
INNER JOIN categorias ON ayudas.id_cat=categorias.id_cat
*/
class AyudasController
{
	
	function __construct()
	{
		
	}

	function index(){
		require_once('Views/Beneficiario/porcedula.php');
	}

	function register(){
		require_once('Views/Beneficiario/register.php');
	}

	function save(){
		if (!isset($_POST['estado'])) {
			$estado="of";
		}else{
			$estado="on";
		}
		
		$beneficiario= new Beneficiario($_POST['id'], $_POST['nombres'],$_POST['apellidos'],$_POST['telefono'],$_POST['ciudad'], $_POST['estado'], $_POST['sector'],$_POST['direccion'],$_POST['estatus'],$_POST['ayudas']);

		Beneficiario::save($beneficiario);
		$this->show();
	}

	function list1(){
		$listaAyudas=Ayudas::list1();

		require_once('Views/Ayudas/show.php');
	}

	function show(){
		$listaAyudas=Ayudas::list1();

		require_once('Views/Ayudas/show.php');
	}

	function updateshow(){
		$id=$_POST['id'];
		$beneficiario=Beneficiario::searchById($id);
		//evaluar contenido de la variable antes de mostrar el form
		require_once('Views/Beneficiario/update.php');
		//require_once('Views/Beneficiario/updateshow.php');
	}

	function update(){
		$beneficiario = new Beneficiario($_POST['id'], $_POST['nombres'],$_POST['apellidos'],$_POST['telefono'],$_POST['ciudad'], $_POST['estado'], $_POST['sector'],$_POST['direccion'],$_POST['estatus'],$_POST['ayudas']);
		Beneficiario::update($beneficiario);
		$this->show();
	}
	function delete(){
		$id=$_POST['id'];
		Beneficiario::delete($id);
		$this->show();
	}

	function search(){
		if (!empty($_POST['id'])) {
			$id=$_POST['id'];
			$beneficiario=Beneficiario::searchById($id);
			$listaBeneficiarios[]=$beneficiario;
			//var_dump($id);
			//var_dump($beneficiario);
			//die();
			require_once('Views/Beneficiario/show.php');
		} else {
			$listaBeneficiarios=Beneficiario::all();

			require_once('Views/Beneficiario/show.php');
		}
		
		
	}

	function error(){
		require_once('Views/Beneficiario/error.php');
	}

	function porcedula(){
		require_once('Views/Beneficiario/porcedula.php');
	}

}

?>