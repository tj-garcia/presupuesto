<?php 
/**
* 
*/
class LoginController
{
	function __construct()
	{
		
	}

	function login(){
		if (!empty($_POST['usuario']) && !empty($_POST['clave'])  ) {
			$id=htmlentities($_POST['usuario']);
			$clave=htmlentities($_POST['clave']);
			$usuario=Usuario::searchById($id);
			$listaUsuarios[]=$usuario;
			if (strtoupper($usuario->getClave())==$clave && strtoupper($usuario->getId())==$id ) {
			  require_once('Views/Layouts/escritorio.php');	
			} else {
			  header("Location: index.php");
			}
			//var_dump($id);
			//die();
		} else {
			  header("Location: index.php");
		}
	}
}
?>