	/* Validaciones de campos */
		function validar(e) { // 1
		    tecla = (document.all) ? e.keyCode : e.which; // 2
		    if (tecla==8) return true; // 3
		    patron =/[abcdefghijklmnñopqrstuvwxyzABCEDFGHIJKLMNÑOPQRSTUVWXYZ ]/;
		    te = String.fromCharCode(tecla); // 5
		    return patron.test(te); // 6
		} 
		function validarC(e) { // 1
		    tecla = (document.all) ? e.keyCode : e.which; // 2
		    if (tecla==8) return true; // 3
		   
			patron = /[1234567890veVE]/;

		    te = String.fromCharCode(tecla); // 5
		    return patron.test(te); // 6
		} 
		function validarn(e) { // 1
		    tecla = (document.all) ? e.keyCode : e.which; // 2
		    if (tecla==8) return true; // 3
		   
			patron = /[1234567890]/;

		    te = String.fromCharCode(tecla); // 5
		    return patron.test(te); // 6
		}
		function validarm(e) { // 1
			
		    tecla = (document.all) ? e.keyCode : e.which; // 2

		    if (tecla==8) return true; // 3
		   
			patron = /^[0-9]+(\.[0-9]+)?$/;

		    te = String.fromCharCode(tecla); // 5
		    return patron.test(te); // 6
		}		
				function validartelf(e) { // 1
		    tecla = (document.all) ? e.keyCode : e.which; // 2
		    if (tecla==8) return true; // 3
		   
			patron = /[1234567890/(/)/-]/;

		    te = String.fromCharCode(tecla); // 5
		    return patron.test(te); // 6
		}

				function validardec(e) { // 1
		    tecla = (document.all) ? e.keyCode : e.which; // 2
		    if (tecla==8) return true; // 3
		   
			patron = /^\d*\.?\d*$/;

		    te = String.fromCharCode(tecla); // 5
		    return patron.test(te); // 6
		}

