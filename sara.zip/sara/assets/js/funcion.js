function SubmitForm(control, action ){
         //alert(control + action);
         document.getElementById("controller0").value = control;
         document.getElementById("action0").value = action;
         document.form0.submit();
     }
function validar(e, tipo) { 
	    tecla = (document.all) ? e.keyCode : e.which; 
	    if (tecla==8) return true; 
		switch (tipo) {
		  case "char":  

		       patron = /^[A-Za-zÁÉÍÓÚáéíóúñÑ ]$/g;
		       break;
		  case "num":
		       patron = /[1234567890]/;
		       break;
		  case "dec":
		       patron = /^\d*\.?\d*$/;
		       break;
		  // …
		  case valueN:
		    //statements
		  default:
		    //statements
		}
		
	    te = String.fromCharCode(tecla); 
	    //alert(patron.test(te));
	    return patron.test(te);//patron.test(te); patt.test(str);
	}

