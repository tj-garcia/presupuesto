<?php 
    session_start(); 
    if (
      	(isset($_POST['controller'])&&isset($_POST['action']))||
      	(isset($_POST['controller0'])&&isset($_POST['action0']))
         ) {
             
		     if (!isset($_SESSION['mensaje'])) {
		       
		       //$_SESSION['time']  = time();
		       //$_SESSION['mensaje']  = ""; 
		      // echo "Inicializando session";     	
		    }	

			$controller = (isset($_POST['controller'])) ? $_POST['controller'] : $_POST['controller0'];
			$action = (isset($_POST['action'])) ? $_POST['action'] : $_POST['action0'];
		    require_once('Views/Layouts/layout.php');
		    //echo date('Y m d H:i:s', $_SESSION['time']);
		    //echo $_SESSION['nombre'];
	    //echo var_dump($_POST);
	    //echo $controller . "--". $action ;	
	} else {
			require_once('Views/Layouts/login.php');
	}
?>

