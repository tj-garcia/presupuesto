<?php 
    
	if (isset($_POST['controller'])&&isset($_POST['action'])) {
		echo $_POST['controller'];
		$controller=$_POST['controller'];
		$action=$_POST['action'];
		echo "You are logged 2...";
      	require_once('connection.php');
	    require_once('Views/Layouts/layout.php');	
	}else{
		require_once('Views/Layouts/login.php');
	}
 ?>