<?php 
    
	if (isset($_POST['controller'])&&isset($_POST['action'])) {
		$controller=$_POST['controller'];
		$action=$_POST['action'];
	    require_once('Views/Layouts/layout.php');	
	}else{
		require_once('Views/Layouts/login.php');
	}
 ?>