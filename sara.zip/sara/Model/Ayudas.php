<?php 
/**
* 
*/
class Ayudas
{
	private $id_ayudas;
	private $id;
	private $id_cat;
	private $asun_ayud;
	private $desc_ayud;
	private $fSol_ayud;
	private $fAdj_ayud;
	private $estat_ayud;
	private $id_us;

	
	function __construct($id_ayudas,$id,$id_cat,$asun_ayud,$desc_ayud,$fSol_ayud,$fAdj_ayud,$estat_ayud,$id_us)
	{
		$this->setAyudas($id_ayudas);
		$this->setId($id);
		$this->setCategoria($id_cat);
		$this->setAsunto($asun_ayud);
		$this->setDescrip($desc_ayud);
		$this->setSolicitud($fSol_ayud);	
		$this->setAprobacion($fAdj_ayud);
		$this->setEstatus($estat_ayud);			
		$this->setUsuario($id_us);
	}

	public function getAyudas(){
		return $this->id_ayudas;
	}

	public function setAyudas($id_ayudas){
		$this->id_ayudas = $id_ayudas;
	}

	public function getId(){
		return $this->id;
	}

	public function setId($id){
		$this->id = $id;
	}

	public function getCategoria(){
		return $this->id_cat;
	}

	public function setCategoria($id_cat){
		$this->id_cat = $id_cat;
	}

	public function getAsunto(){
		return $this->asun_ayud;
	}

	public function setAsunto($asun_ayud){
		$this->asun_ayud = $asun_ayud;
	}

	public function getDescrip(){
		return $this->desc_ayud;
	}

	public function setDescrip($desc_ayud){
		$this->desc_ayud = $desc_ayud;
	}

	public function getSolicitud(){

		return $this->fSol_ayud;
	}

	public function setSolicitud($fSol_ayud){
        $this->fSol_ayud = $fSol_ayud;

	}

	public function getAprobacion(){
		return $this->fAdj_ayud;
	}

	public function setAprobacion($fAdj_ayud){
		$this->fAdj_ayud = $fAdj_ayud;
	}

	public function getDireccion(){
		return $this->direccion;
	}

	public function setDireccion($direccion){
		$this->direccion = $direccion;
	}

	public function getEstatus(){
		return $this->estat_ayud;
	}

	public function setEstatus($estat_ayud){
		$this->estat_ayud = $estat_ayud;
	}
	public function getUsuario(){
		return $this->id_us;
	}

	public function setUsuario($id_us){
		$this->id_us = $id_us;
	}


	public static function save($beneficiario){
		$db=Db::getConnect();
		//var_dump($beneficiario);
		//die();              
                                                                     
		$insert=$db->prepare('INSERT INTO beneficiario VALUES (:id, :nombres,:apellidos,:telefono, :ciudad, :estado, :sector, :direccion, :estatus, :ayudas)');
		$insert->bindValue('id',$beneficiario->getId());
		$insert->bindValue('nombres',$beneficiario->getNombres());
		$insert->bindValue('apellidos',$beneficiario->getApellidos());
		$insert->bindValue('telefono',$beneficiario->getTelefono());
		$insert->bindValue('ciudad',$beneficiario->getCiudad());
		$insert->bindValue('estado',$beneficiario->getEstado());
		$insert->bindValue('sector',$beneficiario->getSector());
		$insert->bindValue('direccion',$beneficiario->getDireccion());
		$insert->bindValue('estatus',$beneficiario->getEstatus());
		$insert->bindValue('ayudas',$beneficiario->getAyudas());
		$insert->execute();
	}

	public static function list1(){
		$db=Db::getConnect();
		$listaAyudas=[];

		$select=$db->query('SELECT ayudas.id_ayudas, beneficiario.nombres, categorias.deno_cat, ayudas.estat_ayud FROM ayudas INNER JOIN beneficiario ON ayudas.id=beneficiario.id INNER JOIN categorias ON ayudas.id_cat=categorias.id_cat order by ayudas.id_ayudas');
        //capturar el array y presentar los datos. No  llamar a la clase, al parecer no hace falta ojo   
		foreach($select->fetchAll() as $ayudas){
			$listaAyudas[]=new Ayudas($ayudas['id_ayudas'],$ayudas['nombres'],$ayudas['deno_cat'],$ayudas['estat_ayud']);
		}            
		return $listaAyudas;
	}

	public static function all(){
		$db=Db::getConnect();
		$listaBeneficiarios=[];

		$select=$db->query('SELECT * FROM beneficiario order by id');

		foreach($select->fetchAll() as $beneficiario){
			$listaBeneficiarios[]=new Beneficiario($beneficiario['id'],$beneficiario['nombres'],$beneficiario['apellidos'],$beneficiario['telefono'],$beneficiario['ciudad'],$beneficiario['estado'],$beneficiario['sector'],$beneficiario['direccion'],$beneficiario['estatus'],$beneficiario['ayudas']);
		}            
		return $listaBeneficiarios;
	}

	public static function searchById($id){
		$db=Db::getConnect();
		$select=$db->prepare('SELECT * FROM beneficiario WHERE id=:id');
		$select->bindValue('id',$id);
		$select->execute();

		$beneficiario=$select->fetch();
		if (!empty($beneficiario['id'])) {
		   $beneficiario2 = new Beneficiario ($beneficiario['id'],$beneficiario['nombres'],$beneficiario['apellidos'],$beneficiario['telefono'],$beneficiario['ciudad'],$beneficiario['estado'],$beneficiario['sector'],$beneficiario['direccion'],$beneficiario['estatus'],$beneficiario['ayudas']);
			//echo "Epa.. ". var_dump($usuarioDb)."epa2";
			//var_dump($usuario);
			//die();
			
		} else {
			$beneficiario2 = new Beneficiario("","","","","","","","","","");
		}
		return $beneficiario2;
	}

	public static function update($beneficiario){
		$db=Db::getConnect();
		$update=$db->prepare('UPDATE beneficiario SET nombres=:nombres, apellidos=:apellidos, telefono=:telefono, ciudad=:ciudad, estado=:estado, estatus=:estatus, ayudas=:ayudas WHERE id=:id');
		$update->bindValue('nombres',$beneficiario->getNombres());
		$update->bindValue('apellidos',$beneficiario->getApellidos());
	    $update->bindValue('telefono',$beneficiario->getTelefono());
		$update->bindValue('ciudad',$beneficiario->getCiudad());
		$update->bindValue('estado',$beneficiario->getEstado());
		$update->bindValue('sector',$beneficiario->getSector());
		$update->bindValue('direccion',$beneficiario->getDireccion());
		$update->bindValue('estatus',$beneficiario->getEstatus());
		$update->bindValue('ayudas',$beneficiario->getAyudas());
		$update->bindValue('id',$beneficiario->getId());
		$update->execute();

	}

	public static function delete($id){
		$db=Db::getConnect();
		$delete=$db->prepare('DELETE  FROM beneficiario WHERE id=:id');
		$delete->bindValue('id',$id);
		$delete->execute();		
	}
}

?>