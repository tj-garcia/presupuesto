<br>
<div class="container footer-site">
		
<footer class="align-items-center  border-top"> 
<hr>
<p class="col-md-12 mb-0 text-muted text-center">© 2023 Alcald&iacute;a del Municipio Leonardo Infante</p>
<!-- py-3 my-4 class="d-flex flex-wrap justify-content-between align-items-center  border-top"
<a href="/" class="col-md-4 d-flex align-items-center justify-content-center mb-3 mb-md-0 me-md-auto link-dark text-decoration-none">
<svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"></use></svg>
</a>
<ul class="nav col-md-4 justify-content-end">
<li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Inicio</a></li>
<li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Precios</a></li>
<li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Acerca</a></li>
</ul>
-->
</footer>
</div>