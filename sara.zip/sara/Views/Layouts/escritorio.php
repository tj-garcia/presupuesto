<?php
//error_reporting(0);
/*
session_start();
if(!isset($_SESSION['P_UsuarioActivo']))
{
  echo "<script>	alert('Error de acceso al sistema...');
                 window.location = '../index.html';
        </script> ";
} else {
  if($_SESSION["P_TipoUsuario"]!='ADMINISTRADOR'){
  echo "<script>  alert('No tiene credenciales para usar este modulo...');
                 window.location = 'index.php';
        </script> ";    
  }
}
	require_once('conexion/conexion_i.php');
	include_once('conexion/funciones.php');
	*/
?>
<!-- 
<div class="alert alert-success">
  <strong>Bienvenido!</strong>.
</div>
 -->

     <div class="col-md-12 roboto escritorio text-center">

        <form name="form2" id="form2" class="form-signin border border-success rounded border-2  bg-white" method="post" action="index.php">
          <p roboto>SISTEMA PARA EL SEGUIMIENTO DE APORTES SOCIALES <br> ALCALDÍA DE INFANTE</p>

          <!-- <img class="mb-4" src="assets/icon/cintillo.jpg" alt="" width="10%" height="10%">   -->

          <input type="hidden" id="controller" name="controller" class="form-control" placeholder="" value="default">
          <input type="hidden" id="action" name="action" class="form-control" placeholder="" value="escritorio">



        </form>          
     </div>