<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="assets/icon/favicon.ico">

    <title>SARA</title>
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">  

    <!-- Custom styles for this template -->
    <link href="assets/css/login.css" rel="stylesheet">  
    <!-- <link href="assets/css/estilos.css" rel="stylesheet"> -->
    
  </head>

  <body class="text-center">
     <div class="container">

        <form class="form-signin border border-success rounded border-2  bg-white" method="post" action="index.php">

          <img class="mb-4" src="assets/icon/cintillo.jpg" alt="" width="90" height="90">

          <h1 class="h3 mb-3 font-weight-medium">Acceder al Sistema</h1>

          <label for="usuario" class="sr-only"></label>
          <input type="text" id="usuario" name="usuario" class="form-control" placeholder="Usuario" required autofocus>
          <input type="hidden" id="controller" name="controller" class="form-control" placeholder="" value="beneficiario">
          <input type="hidden" id="action" name="action" class="form-control" placeholder="" value="index">


          <label for="clave" class="sr-only"></label>
          <input type="password" id="clave" name="clave" class="form-control" placeholder="Clave" required>

          <button class="btn mt-3 btn-outline-success  "  type="submit" name="entrar">Aceptar</button>
          <button class="btn mt-3 btn-outline-success "  type="submit" name="cancelar">Cancelar</button>
          <!--<p class="mt-5 mb-3 text-muted">&copy; 2022</p>   btn-outline-success-->

        </form>          
     </div>
     <script src="assets/js/bootstrap.min.js"></script>        
     <script src="assets/js/bootstrap.bundle.min.js"></script>
     <script src="assets/js/index.js"></script>
  </body>
</html>