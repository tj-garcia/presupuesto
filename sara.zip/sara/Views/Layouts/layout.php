<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="assets/icon/favicon.ico">

    <title>SARA</title>
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">  

    <!-- Custom styles for this template -->
    <link href="assets/css/estilos.css" rel="stylesheet">  
    <!-- <link href="assets/css/estilos.css" rel="stylesheet"> -->
    
  </head>

  <body > <!-- class="text-center"  -->
     
     <div class="container">
        <?php require_once('Views/Layouts/menu.php'); ?>   
        <?php require_once('routing.php'); ?>
        <?php require_once('Views/Layouts/pie.php'); ?>        	
     </div>
           
     <script src="assets/js/bootstrap.bundle.min.js"></script>
     <!-- <script src="assets/js/bootstrap.bundle.js"></script> -->
     <!--<script src="assets/js/bootstrap.min.js"></script>    -->    
     <script src="assets/js/index.js"></script>
     <script src="assets/js/funcion.js"></script>
     <script src="assets/js/canvasjs.min.js"></script> <!-- eliminar -->
  </body>
</html>



<!--
<!DOCTYPE html>
<html lang="es">
<head>
	<title>Crud PHP</title>
	<meta charset="utf-8">

	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<script src="https://npmcdn.com/tether@1.2.4/dist/js/tether.min.js"></script>
	<script type="text/javascript" src="assets/js/jquery-3.2.1.min.js"></script>

	<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
	
</head>
<body>
	<header>
		<?php 
			//require_once('cabecera.php');
		 ?>
		
	</header>
	<section>
		<?php 
			//require_once('routing.php');
		?>
	</section>

</body>
</html>

-->