<?php
//error_reporting(0);
/*
session_start();
if(!isset($_SESSION['P_UsuarioActivo']))
{
  echo "<script>	alert('Error de acceso al sistema...');
                 window.location = '../index.html';
        </script> ";
} else {
  if($_SESSION["P_TipoUsuario"]!='ADMINISTRADOR'){
  echo "<script>  alert('No tiene credenciales para usar este modulo...');
                 window.location = 'index.php';
        </script> ";    
  }
}
	require_once('conexion/conexion_i.php');
	include_once('conexion/funciones.php');
	*/
?>
<!-- 
<div class="alert alert-success">
  <strong>Bienvenido!</strong>.
</div>
 -->
<form class="row g-3 form-signin" method="post" action="index.php">
  <div class="col-md-12">
    <h2>BUSCAR POR C&Eacute;DULA</h2>
  </div>
  <div class="col-md-4">
    <label for="cedula" class="form-label">C&eacute;dula:</label>
    <input type="number" class="form-control" id="cedula" name="cedula" min="99999" max="99999999" placeholder="99999999">
    <input type="hidden" class="form-control" id="controller" name="controller" value="beneficiario">
    <input type="hidden" class="form-control" id="action" name="action" value="show">
  </div>
  <hr>  
  <div class="col-6 text-center">
    <button type="submit" class="btn mt-3 btn-outline-success">Buscar</button>
  </div>
  <div class="col-6  text-center">
    <button type="reset" class="btn mt-3 btn-outline-success">Cancelar</button>
  </div>
</form>