<div class="alert alert-success">
  <strong>Bienvenido!</strong>.
</div>