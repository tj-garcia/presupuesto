<div class="alert alert-danger">
  <strong>Error!</strong>.
</div>