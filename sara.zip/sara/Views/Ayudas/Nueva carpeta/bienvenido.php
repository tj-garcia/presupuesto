<?php
//error_reporting(0);
/*
session_start();
if(!isset($_SESSION['P_UsuarioActivo']))
{
  echo "<script>	alert('Error de acceso al sistema...');
                 window.location = '../index.html';
        </script> ";
} else {
  if($_SESSION["P_TipoUsuario"]!='ADMINISTRADOR'){
  echo "<script>  alert('No tiene credenciales para usar este modulo...');
                 window.location = 'index.php';
        </script> ";    
  }
}
	require_once('conexion/conexion_i.php');
	include_once('conexion/funciones.php');
	*/
?>
<div class="alert alert-success">
  <strong>Bienvenido!</strong>.
</div>

<form class="row g-3 form-signin">
  <div class="col-md-12">
    <h2>BENEFICIARIOS</h2>
  </div>
  <div class="col-md-4">
    <label for="cedula" class="form-label">C&eacute;dula:</label>
    <input type="text" class="form-control" id="cedula">
  </div>
  <div class="col-md-4">
    <label for="nombre" class="form-label">Nombre</label>
    <input type="text" class="form-control" id="nombre">
  </div>
  <div class="col-md-4">
    <label for="apellido" class="form-label">Apellido</label>
    <input type="text" class="form-control" id="apellido">
  </div>

  <div class="col-md-4">
    <label for="telefono" class="form-label">Tel&eacute;fono</label>
    <input type="text" class="form-control" id="telefono">
  </div>
  <div class="col-md-4">
    <label for="ciudad" class="form-label">Ciudad</label>
    <input type="text" class="form-control" id="ciudad">
  </div>
  <div class="col-md-4">
    <label for="Estado" class="form-label">Estado</label>
    <select id="Estado" class="form-select">
      <option selected>Choose...</option>
      <option>...</option>
    </select>
  </div>


  <div class="col-12">
    <label for="sector" class="form-label">Sector</label>
    <input type="text" class="form-control" id="sector" placeholder="Sector">
  </div>
  <div class="col-12">
    <label for="direccion" class="form-label">Direcci&oacute;n</label>
    <input type="text" class="form-control" id="direccion" placeholder="Sector A, Calle B, Casa 1...">
  </div>
  <hr>
  <div class="col-md-12">
    <h3>SOLICITUD</h3>
  </div>  
  <div class="col-md-6">
    <label for="categoria" class="form-label">Categor&iacute;a</label>
    <select id="categoria" class="form-select">
      <option selected>Choose...</option>
      <option>...</option>
    </select>
  </div>
  <div class="col-md-6">
    <label for="estatus" class="form-label">Estatus</label>
    <select id="estatus" class="form-select">
      <option selected>Choose...</option>
      <option>...</option>
    </select>
  </div>
  <div class="col-md-12">
    <label for="descripcion" class="form-label">Descripci&oacute;n</label>
    <textarea class="form-control" id="descripcion" rows="3"></textarea>
  </div>  
  <hr>  


  <div class="col-6 text-center">
    <button type="submit" class="btn mt-3 btn-outline-success">Grabar</button>
  </div>
  <div class="col-6  text-center">
    <button type="reset" class="btn mt-3 btn-outline-success">Cancelar</button>
  </div>
</form>