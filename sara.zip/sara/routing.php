<?php
    require_once('connection.php');
    //echo "routing";  
	switch ($controller) {
		case 'beneficiario':
		     $controllers=array('beneficiario'=>['index','register','save','show','updateshow','update','delete','search','error']);
		break;			
		case 'alumno':
		     $controllers=array('alumno'=>['index','register','save','show','updateshow','update','delete','search','error']);
		break;
		default:
				# code...
		break;
	}



	if (array_key_exists($controller,  $controllers)) {
		if (in_array($action, $controllers[$controller])) {
			call($controller, $action);
		}
		else{
			call('alumno','error');
		}		
	}else{
		call('alumno','error');
	}

	function call($controller, $action){
		require_once('Controllers/'.$controller.'Controller.php');

		switch ($controller) {
			case 'alumno':
			require_once('Model/Alumno.php');
			$controller= new UsuarioController();
			break;			
			case 'beneficiario':
			require_once('Model/beneficiario.php');
			$controller= new UsuarioController();
			break;			
			default:
					# code...
			break;
		}
		$controller->{$action}();
	}
?>