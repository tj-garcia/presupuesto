<div class="container">
  <ul class="nav">
    <li class="nav-item">
      <a class="nav-link" href="?controller=alumno&action=register">Registrar</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="?controller=alumno&&action=show">Ver</a>
    </li>
  </ul>
</div>