<link rel="stylesheet" href="assets/DataTables/datatables.css" />
	<div class="table-responsive form-signin">
		<h2>Lista Beneficiarios</h2><br>
		<table class="table table-striped" id="tabla1"> <!--table table-hover-->
			<thead>
				<tr>
					<th>C&eacute;dula</th>
					<th>Nombres</th>
					<th></th>
				</tr>
				<tbody>
					<?php foreach ($listaBeneficiarios as $beneficiario) {?>
						
					<tr>
						<td><?php echo $beneficiario->getId(); ?></td>
						<td><?php echo $beneficiario->getNombres()." ".$beneficiario->getApellidos(); ?></td>
						<td><button class="btn btn-outline-primary "  ><i class="bi bi-shield-plus"></i></button></td>

					</tr>
					<?php } ?>
				</tbody>

			</thead>
		</table>

	</div>	

<script src="assets/DataTables/datatables.js"></script>
<script>
$(document).ready( function () {
$('#tabla1').DataTable({
	responsive: true ,
    "language": {
      "url": "assets/DataTables/es-ES.json"
    }
  });
} );
</script>