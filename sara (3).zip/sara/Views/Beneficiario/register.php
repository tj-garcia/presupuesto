<form class="row g-3 form-signin" name="form2" method="post" action="index.php">
  <div class="col-md-12">
    <h2>BENEFICIARIOS</h2>
  </div>
  <div class="col-md-4">
    <label for="id" class="form-label">C&eacute;dula:</label>
    <input type="text" class="form-control" id="id" name="id" required>
  </div>
  <div class="col-md-4">
    <label for="nombres" class="form-label">Nombres</label>
    <input type="text" class="form-control" id="nombres" name="nombres" onkeydown="return validar(event, 'char')" required minlength="3" maxlength="20" >
  </div>
  <div class="col-md-4">
    <label for="apellidos" class="form-label">Apellidos</label>
    <input type="text" class="form-control" id="apellidos" name="apellidos" onkeydown="return validar(event, 'char')" required minlength="3" maxlength="20">
  </div>

  <div class="col-md-4">
    <label for="telefono" class="form-label">Tel&eacute;fono</label>
    <input type="tel" class="form-control" id="telefono" name="telefono" onkeydown="return validar(event, 'num')" required minlength="11" maxlength="11" inputmode="numeric">
  </div>
  <div class="col-md-4">
    <label for="ciudad" class="form-label">Ciudad</label>
    <input type="text" class="form-control" id="ciudad" name="ciudad" onkeydown="return validar(event, 'char')" required minlength="3" maxlength="60">
  </div>
  <div class="col-md-4">
    <label for="estado" class="form-label">Estado</label>
    <input type="text" class="form-control" id="estado" name="estado" onkeydown="return validar(event, 'char')" required minlength="3" maxlength="60">

<select class="form-select form-select-sm" aria-label=".form-select-sm example">
  <option selected>Open this select menu</option>
  <option value="1">One</option>
  <option value="2">Two</option>
  <option value="3">Three</option>
</select>

    
  </div>

  <div class="col-12">
    <label for="sector" class="form-label">Sector</label>
    <input type="text" class="form-control" id="sector" placeholder="Sector" name="sector" onkeydown="return validar(event, 'char')" required minlength="3" maxlength="60">
  </div>
  <div class="col-12">
    <label for="direccion" class="form-label">Direcci&oacute;n</label>
    <input type="text" class="form-control" id="direccion" placeholder="Sector A, Calle B, Casa 1..." name="direccion" onkeydown="return validar(event, 'char')" required minlength="3" maxlength="80">
  </div>

  <div class="col-12">
       <input type="hidden" id="controller" name="controller" class="form-control" placeholder="" value="beneficiario">
       <input type="hidden" id="action" name="action" class="form-control" placeholder="" value="save">
       <input type="hidden" id="estatus" name="estatus" class="form-control" placeholder="" value="">
       <input type="hidden" id="ayudas" name="ayudas" class="form-control" placeholder="" value="0">
  </div>


  <hr>


  <div class="col-6 text-center">
    <button type="submit" class="btn mt-3 btn-outline-success">Grabar</button>
  </div>
  <div class="col-6  text-center">
    <button type="reset" class="btn mt-3 btn-outline-success">Cancelar</button>
  </div>

</form>