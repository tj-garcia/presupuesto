-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-07-2023 a las 12:13:23
-- Versión del servidor: 10.1.9-MariaDB
-- Versión de PHP: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `crud`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumno`
--

CREATE TABLE `alumno` (
  `id` int(11) NOT NULL,
  `nombres` varchar(255) DEFAULT NULL,
  `apellidos` varchar(255) DEFAULT NULL,
  `estado` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `alumno`
--

INSERT INTO `alumno` (`id`, `nombres`, `apellidos`, `estado`) VALUES
(1, 'Elivar Oswaldo', 'Largo Rios', '1'),
(5, 'Juan', 'Vargas', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `beneficiario`
--

CREATE TABLE `beneficiario` (
  `id_benef` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `nombres` varchar(40) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(40) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(11) COLLATE utf8_spanish_ci NOT NULL,
  `ciudad` varchar(40) COLLATE utf8_spanish_ci NOT NULL DEFAULT 'VALLE DE LA PASCUA',
  `id_estado` int(2) NOT NULL DEFAULT '12',
  `sector` varchar(40) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `estatus` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `ayudas` int(3) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `beneficiario`
--

INSERT INTO `beneficiario` (`id_benef`, `nombres`, `apellidos`, `telefono`, `ciudad`, `id_estado`, `sector`, `direccion`, `estatus`, `ayudas`) VALUES
('10000000', 'nombre', 'apellido', 'telefono', 'ciudad', 12, 'sector', 'direccion', 'activo', 0),
('10975000', 'ana', 'padron', '02353410000', 'valle de la pascua', 0, 'sector', 'calle 1 casa 2 sector 3', '', 0),
('10982453', 'ORTIZ WILLIAN ', '', '0414-201912', 'VALLE DE LA PASCUA', 12, '', 'CALLE ILUSTRE CRESE CON 23 DE ENERO, CASA 67, SECTOR MORICHAL', '', 0),
('13680610', 'JOSLLEN JOSUE VASQUEZ FLORES', '', '0424-332886', 'VALLE DE LA PASCUA', 12, '', 'CALLE NICARAGUA, CASA N? 10, SECTOR CARLOS PEREZ', '', 0),
('1472089', 'ANA BASILIA TAVERA DE AGREDA', '', '0424-332292', 'VALLE DE LA PASCUA', 12, '', 'AVENIDA LIBERTADO, CASA N? 07', '', 0),
('1482314', 'ENMA RAMONA VAZQUEZ', '', '0412-270353', 'VALLE DE LA PASCUA', 12, '', 'CALLE LA GUARDIA, CASA N? 07, SECYOR LA AGUSTINA', '', 0),
('1484421', 'JUSTINA BORREGO', '', '11111111111', 'VALLE DE LA PASCUA', 12, '', 'SECTOR 5 DE JULIO NORTE', '', 0),
('1485012', 'TORREALBA RAMON EUCLIDES', '', '11111111111', 'VALLE DE LA PASCUA', 12, '', 'CALLE PRINCIPAL CASERIO MAHOMITO', '', 0),
('18895124', 'JORGE LUIS CAMACHO HIGUERA', '', '0424-313456', 'VALLE DE LA PASCUA', 12, '', 'CALLE PRIMERO DE MAYO, SECTOR ALFALLANO', '', 0),
('19361327', 'MANUEL ALEJANDRO FERNANDEZ LUSINCHE', '', '0424-326303', 'VALLE DE LA PASCUA', 12, '', 'SECTOR COROZAL', '', 0),
('19964235', 'CARLOS JAVIER LICET ARZOLA', '', '4142947375', 'VALLE DE LA PASCUA', 12, '', 'CALLE COSTA RICA, CASA N? 21, SECTOR CARLOS PEREZ', '', 0),
('2000000', 'pedro jose', 'araujo escalona', '20', '20', 12, '20', 'direccion20', 'activo', 0),
('20261067', 'SERGIO JOSE -REQUENA CARRERO', '', '0426-345906', 'VALLE DE LA PASCUA', 12, '', 'CALLE 11, CASA N? 39, SECTOR PEDRE CHACIN', '', 0),
('21312247', 'YOSDENY MILAGRO GONZALEZ SUAREZ', '', '0416-734219', 'VALLE DE LA PASCUA', 12, '', 'CALLE 01, CASA N? 1-A, SECTOR EL PARQUE', '', 0),
('21313334', 'JESUS MANUEL SANCHEZ GONZALEZ', '', '0412-498738', 'VALLE DE LA PASCUA', 12, '', 'VEREDA 22, CASA N? 15, SECTOR LAS GARCITAS', '', 0),
('2392729', 'DOLORES PULIDO DE CASTILLO ', '', '4243228998', 'VALLE DE LA PASCUA', 12, '', 'CALLE ILUSTRE CRESE CON 23 DE ENERO, CASA 67, SECTOR MORICHAL', '', 0),
('2395812', 'RAFAEL NEPTALI BASTARDO BASTARDO', '', '0416-640855', 'VALLE DE LA PASCUA', 12, '', 'CALLE 02, CASA N? 100, SECTOR LOS CERRITOS', '', 0),
('24619637', 'MIGUEL ANGEL TORRES BUTRIAGO', '', '0426-243721', 'VALLE DE LA PASCUA', 12, '', 'CALLE SAN JOSE, CASA N?38, SECTOR LA REPRESA', '', 0),
('26', 'LUGO ROSA ', '', '4163384013', 'VALLE DE LA PASCUA', 12, '', 'SECTOR SANMIGUEL CASA36', '', 0),
('26299248', 'NATHALIA ELIZABETH HERRERA CAMEJO', '', 'NO POSEE', 'VALLE DE LA PASCUA', 12, '', 'CALLE MAGALLANES, CASA N? 42, SECTOR LA ROMANA', '', 0),
('26299404', 'NESTOR DANIEL RAMOS BERROETA', '', '0416-243479', 'VALLE DE LA PASCUA', 12, '', 'AVENIDA 02, CASA N? 82, SECTOR PADRE CHACIN', '', 0),
('26464707', 'YAURY MORALES ', '', 'NO POSEE', 'VALLE DE LA PASCUA', 12, '', 'SECTOR LA BENDICION DE DIOS ', '', 0),
('2749434', 'ANTONIO RAMON SILVERA', '', 'NO POSEE', 'VALLE DE LA PASCUA', 12, '', 'VEREDA 28, CASA N? 02, SECTOR LAS GARCITAS', '', 0),
('28292532', 'EDDY GUILLERMO TORREALBA ESPINOZA', '', '0424-330300', 'VALLE DE LA PASCUA', 12, '', 'CALLE SAN MIGUEL, CASA N? 57, SECTOR LA ROMANA', '', 0),
('28292539', 'DANIELA DE JESUS ', '', '0412-976094', 'VALLE DE LA PASCUA', 12, '', 'CALLE PARAISO, CASA N? 103, SECTOR MORICHAL', '', 0),
('30000000', 'treinta', 'treinta', '02353000000', 'valle de la pascua', 12, 'sector', 'direccion', 'activo', 0),
('30152846', 'PAMELA DEL VALLE OLIVARES PRADO', '', '0416-011808', 'VALLE DE LA PASCUA', 12, '', 'CALLE CUBA, CASA N? 34, SECTOR CARLOS PEREZ', '', 0),
('30153399', 'MAURO ALEJANDRO RENGIFO CHACIN', '', '0412-389869', 'VALLE DE LA PASCUA', 12, '', 'ESTACIONAMIENTO LA COBRA, SECTOR CRISTO REY', '', 0),
('30264415', 'XIOMARA COROMOTO LOPEZ TORREALBA', '', '0426-033264', 'VALLE DE LA PASCUA', 12, '', 'CALLE MAGALLANES, CASA N? 35, SECTOR LA PUA', '', 0),
('31575812', 'DOUGLAS ALEXANDER HERRERA HERRERA', '', '0416-395045', 'VALLE DE LA PASCUA', 12, '', 'CALLE CAMALEONES SUR, CASA N? 141-1, SECTOR CENTRO', '', 0),
('32075179', 'VERONICA CAROLINA MALAVE MALAVE', '', '0424-843874', 'VALLE DE LA PASCUA', 12, '', 'CALLLE REAL, CASA N? 80, SECTOR CENTRO', '', 0),
('3218236', 'RENGIFO ALFONSO RAFAEL', '', '0416-942316', 'VALLE DE LA PASCUA', 12, '', 'CALLE 04, VEREDA 13, CASA N? 06, SECTOR LAS GARCITAS', '', 0),
('32307291', 'WHARNNY MARGARITA ZAMBRANO SUAREZ', '', '0416-314552', 'VALLE DE LA PASCUA', 12, '', 'CALLE N? 03, SECTOR MORICHAL', '', 0),
('32604014', 'JUAN DE JESUS MONCADO MONCADO', '', '4129763590', 'VALLE DE LA PASCUA', 12, '', 'CALLE SANTA INES, CASA N? 04, SECTOR LA REPRESA', '', 0),
('345946', 'PEDRO JOSE BORGES', '', '4161860690', 'VALLE DE LA PASCUA', 12, '', 'CALLE GUASCO, CASA N? 79, SECTOR CENTRO', '', 0),
('3639190', 'MARIA MAITA DE QUI?ONES', '', '0414-453139', 'VALLE DE LA PASCUA', 12, '', 'CALLE LA GUARDIA, CASA N? 32, SECTOR LA AGUSTINA', '', 0),
('3641262', 'JOSE FRANCISCO PERDOMO?', '', '0412-881739', 'VALLE DE LA PASCUA', 12, '', 'CALLE 23 DE ENERO, ENTRE BOLIVAR Y FLORES', '', 0),
('3951355', 'GILLERMO LEDEZMA', '', '0426-132621', 'VALLE DE LA PASCUA', 12, '', 'SECTOR JOSE FELIX RIBAS', '', 0),
('3991648', 'MOISES ANTONIO HERNANDEZ', '', '0424-301167', 'VALLE DE LA PASCUA', 12, '', 'VEREDA 12, CASA N? 12, SECTOR LAS GARCITAS', '', 0),
('4307229', 'BETTY JOSEFINA RAMIREZ ALVAREZ', '', '0412-777482', 'VALLE DE LA PASCUA', 12, '', 'CALLESTADIUM, CASA N? 60, SECTOR PLAYA VERDE', '', 0),
('4308949', 'JOSE FRANCISCO HERRERA', '', '0426-346345', 'VALLE DE LA PASCUA', 12, '', 'CALLE ARISMENDI, SECTOR STADIUM', '', 0),
('4799301', 'MARA FRANCISCA ORTEGA LANDAETA', '', '0426-444352', 'VALLE DE LA PASCUA', 12, '', 'SECTOR RURAL LAS CAMPECHANAS', '', 0),
('4800190', 'REINA EMPERATRIZ REQUENA SOUBLETT', '', 'NO POSEE', 'VALLE DE LA PASCUA', 12, '', 'CALLE ORITUCO NORTE, CASA N? 53, SECTOR LA ROMANA', '', 0),
('4833765', 'CARMEN DOLORES ALVAREZ DE RENGIFO', '', '0426-713365', 'VALLE DE LA PASCUA', 12, '', 'VEREDA 04, CASA N? 07, SECTOR 04 LAS GARCITAS', '', 0),
('4833836', 'JOSE RUBEN RODRIGUEZ', '', '4243295672', 'VALLE DE LA PASCUA', 12, '', 'CALLE 01, CASA N? G-27, SECTOR LAS CAROLINAS', '', 0),
('5333866', 'JOSEFA ANTONIA MILANO HERNANDEZ', '', '4264470777', 'VALLE DE LA PASCUA', 12, '', 'CALLE RETUMBO SUR, SECTOR CENTRO, CASA N? 108', '', 0),
('5622122', 'EDUARDO RAMON TAVERA HERNANDEZ', '', '0416-144931', 'VALLE DE LA PASCUA', 12, '', 'CALLE ESMERALDA, CASA N? 05, SECTOR CORAZON DE DIOS', '', 0),
('792662', 'ISIDRA BELLORIN', '', '0412-387101', 'VALLE DE LA PASCUA', 12, '', 'valle de la pascua', '', 0),
('8560340', 'YOMAIRA JOSEFINA RAMIREZ', '', '0426-847799', 'VALLE DE LA PASCUA', 12, '', 'CALLE 11, CASA N? 34, SECTOR PADRE CHACIN', '', 0),
('8796462', 'MARIA ESTHER RENGIFO MARTINEZ', '', '0426-430851', 'VALLE DE LA PASCUA', 12, '', 'CALLE 03, SECTOR MORICHAL', '', 0),
('8796978', 'JUAN MANUEL REQUENA SOUBLETT', '', '0416-734021', 'VALLE DE LA PASCUA', 12, '', 'CALLE ORINOCO, CASA N? 53, SECTOR LA ROMANA', '', 0),
('9817936', 'GUIOMAR DEL CARMEN HERRERA MATA', '', '0412-476216', 'VALLE DE LA PASCUA', 12, '', 'CALLE 5, CASA N? 17, SECTOR LAS GARCITAS', '', 0),
('9918267', 'RAFAEL ZAMORA', '', '0235-341896', 'VALLE DE LA PASCUA', 12, '', 'CALLE 04, VEREDA 09, CASA N? 12, LAS GARCITAS', '', 0),
('9918335', 'LIGIA ARACELIS FIGUEROA DE LARA', '', '0426-144870', 'VALLE DE LA PASCUA', 12, '', 'VEREDA 17, CASA N? 06, SECTOR LAS ACACIAS', '', 0),
('13513601', 'JEAN', 'RODRIGUEZ', '04262440488', 'VALLE DE LA PASCUA', 0, 'AUTOCONSTRUCCION', 'CALLE SUCRE 125', '', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id_cat` varchar(5) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `deno_cat` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `ay_sol_cat` int(7) NOT NULL,
  `ay_aprob_cat` int(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id_cat`, `deno_cat`, `ay_sol_cat`, `ay_aprob_cat`) VALUES
('01000', 'MEDICINAS', 0, 0),
('01001', 'COMPRA MEDICINAS', 0, 0),
('01002', 'PAGO CONSULTA', 0, 0),
('01003', 'EXÁMENES MÉDICOS', 0, 0),
('01004', 'BASTONES', 0, 0),
('01005', 'MULETAS', 0, 0),
('01006', 'SILLA DE RUEDAS', 0, 0),
('02000', 'ALIMENTOS', 0, 0),
('02001', 'COMPRA ALIMENTOS', 0, 0),
('03000', 'VIVIENDA', 0, 0),
('03001', 'ADJUDICACION DE VIVIENDA', 0, 0),
('03002', 'REPARACIONES', 0, 0),
('03004', 'MATERIALES', 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `consejoc`
--

CREATE TABLE `consejoc` (
  `codi_consc` varchar(4) COLLATE utf8_spanish_ci NOT NULL,
  `deno_consc` varchar(34) COLLATE utf8_spanish_ci DEFAULT '""',
  `tipo_consc` varchar(6) CHARACTER SET utf8 COLLATE utf8_spanish2_ci DEFAULT 'RURAL',
  `donac_consc` int(7) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `consejoc`
--

INSERT INTO `consejoc` (`codi_consc`, `deno_consc`, `tipo_consc`, `donac_consc`) VALUES
('0101', 'VALLE CINCO LAS PARADAS', 'RURAL', 0),
('0102', 'CAMPO ALEGRE', 'RURAL', 0),
('0103', 'SANTA ROSA DE PARDILLAL', 'RURAL', 0),
('0104', 'CARRIZALITO LAS COCUIZAS', 'RURAL', 0),
('0105', 'LOS CAROS', 'RURAL', 0),
('0106', 'EL BOSTERO', 'RURAL', 0),
('0107', 'SANTA ANA DE MANIRAL II', 'RURAL', 0),
('0108', 'SANTA ANA DE MANIRAL I', 'RURAL', 0),
('0109', 'EL PARAMO', 'RURAL', 0),
('0110', 'PATRIA NUEVA ', 'RURAL', 0),
('0111', 'EL COROZO I JUAN FIDEL ', 'RURAL', 0),
('0112', 'EL COROZO', 'RURAL', 0),
('0113', 'TERRAZAS DEL LIDO', 'URBANO', 0),
('0114', 'JARDIN LA PASCUA', 'URBANO', 0),
('0115', 'VILLA ROSARIO', 'URBANO', 0),
('0116', 'EL REMANSO', 'URBANO', 0),
('0117', 'JHON SILVA', 'URBANO', 0),
('0118', 'LA REPRESA LOS COCOS', 'URBANO', 0),
('0119', 'LAS ACACIAS', 'URBANO', 0),
('0120', 'LA BENDICION DE DIOS', 'URBANO', 0),
('0121', 'FLORIDA I', 'URBANO', 0),
('0122', 'FLORIDA II', 'URBANO', 0),
('0123', 'EL PROGRESO', 'URBANO', 0),
('0124', 'RUIZ PINEDA', 'URBANO', 0),
('0125', 'LOS BLOQUES DE LA PUA', 'URBANO', 0),
('0126', 'COCA COLA', 'URBANO', 0),
('0127', 'LA ROMANA', 'URBANO', 0),
('0128', 'BRISAS DEL NORTE', 'URBANO', 0),
('0129', 'EL SAMAN', 'URBANO', 0),
('0130', 'PLAYA VERDE ', 'URBANO', 0),
('0131', 'EL CERRITO', 'URBANO', 0),
('0132', 'LA CONCORDIA', 'URBANO', 0),
('0133', 'SAN MIGUEL III ', 'URBANO', 0),
('0134', 'SAN MIGUEL II ', 'URBANO', 0),
('0135', 'SAN MIGUEL I', 'URBANO', 0),
('0136', '5 DE JULIO NORTE ', 'URBANO', 0),
('0137', '5 DE JULIO SUR', 'URBANO', 0),
('0138', 'EL ROSARIO', 'URBANO', 0),
('0139', 'VAPORON', 'URBANO', 0),
('0140', 'AREVALO CEDE?O', 'URBANO', 0),
('0141', 'ALFALLANO', 'URBANO', 0),
('0142', 'CALLE NUEVA ', 'URBANO', 0),
('0143', 'LOS ILUSTRES ', 'URBANO', 0),
('0144', 'LUCHA Y TRIUNFARAS', 'URBANO', 0),
('0201', 'PUENTE EL GALLO LA PELA', 'RURAL', 0),
('0202', 'LAS BABAS', 'RURAL', 0),
('0203', 'LAS CAMPECHANAS', 'RURAL', 0),
('0204', 'VELASQUEZ', 'RURAL', 0),
('0205', 'AGUADA EL CALVARIO', 'RURAL', 0),
('0206', 'LOMA ALTA', 'RURAL', 0),
('0207', 'ZANJONOTE DE LA MONTAÑA', 'RURAL', 0),
('0208', 'PELE EL OJO', 'RURAL', 0),
('0209', 'ERNESTO CHE GUEVARA', 'RURAL', 0),
('0210', 'LOMA DE PIEDRA', 'RURAL', 0),
('0211', 'CORAZON DE JESUS', 'URBANO', 0),
('0212', 'LOMAS DEL ESTE', 'URBANO', 0),
('0213', 'LA TRINIDAD', 'URBANO', 0),
('0214', 'LA GRACIA DE DIOS', 'URBANO', 0),
('0215', 'JOSE FELIX RIBAS II', 'URBANO', 0),
('0216', 'JOSE FELIX RIBAS I', 'URBANO', 0),
('0217', 'BRISAS DEL ESTE', 'URBANO', 0),
('0218', '4 DE FEBRERO', 'URBANO', 0),
('0219', 'COLINAS DEL VALLE', 'URBANO', 0),
('0220', 'LA OBRA DE DIOS', 'URBANO', 0),
('0221', 'CANOAS UNIVERSIDAD', 'URBANO', 0),
('0222', 'PADRE CHACIN I', 'URBANO', 0),
('0223', 'PADRE CHACIN II ', 'URBANO', 0),
('0224', 'LIRIOS DEL VALLE', 'URBANO', 0),
('0225', 'AUTOCONSTRUCCION I', 'URBANO', 0),
('0226', 'AUTOCONSTRUCCION II', 'URBANO', 0),
('0227', 'LA AGUSTINA', 'URBANO', 0),
('0228', 'GARCITAS V', 'URBANO', 0),
('0229', 'GARCITAS IV', 'URBANO', 0),
('0230', 'GARCITAS III', 'URBANO', 0),
('0231', 'GARCITAS II', 'URBANO', 0),
('0232', 'GARCITAS I', 'URBANO', 0),
('0233', 'LA ESPERANZA', 'URBANO', 0),
('0234', 'AEROPUERTO', 'URBANO', 0),
('0235', 'MORICHAL VENCEDORES ', 'URBANO', 0),
('0236', 'PASCUA CITY', 'URBANO', 0),
('0237', 'PARAISO ESTE CASCO CENTRAL', 'URBANO', 0),
('0238', 'BOULEVAR GUASCO', 'URBANO', 0),
('0239', 'SOMOS ESPERANZA', 'URBANO', 0),
('0240', 'MINAS DE ARENA', 'URBANO', 0),
('0241', 'EL ZAMURO', 'URBANO', 0),
('0242', 'LOS CERRITOS I', 'URBANO', 0),
('0243', 'LOS CERRITOS II', 'URBANO', 0),
('0244', 'LOS CERRITOS III', 'URBANO', 0),
('0245', 'VALLE DE SARON', 'URBANO', 0),
('0246', 'EL PALMAR I', 'URBANO', 0),
('0247', 'EL PALMAR II', 'URBANO', 0),
('0248', 'EL PALMAR III-1', 'URBANO', 0),
('0249', 'EL PALMAR III-2', 'URBANO', 0),
('0250', 'EL PALMAR III-3', 'URBANO', 0),
('0251', 'LA CANDELARIA', 'URBANO', 0),
('0252', 'MARIA DE SAN JOSÉ', 'URBANO', 0),
('0301', 'MATA REDONDA', 'RURAL', 0),
('0302', 'MATA REDONDA I', 'RURAL', 0),
('0303', 'POTRERITO', 'RURAL', 0),
('0304', 'CAÑAVERAL', 'RURAL', 0),
('0305', 'SAN PEDRO', 'RURAL', 0),
('0306', 'LA MALQUERIDA', 'RURAL', 0),
('0307', 'EL CARITO', 'RURAL', 0),
('0308', 'LA PEREÑA', 'RURAL', 0),
('0309', 'DOS CAMINOS', 'RURAL', 0),
('0310', 'PARDILLAL TERRONAL Y SAN RAMON', 'RURAL', 0),
('0311', 'EL BURRO EL PAUJI ', 'RURAL', 0),
('0312', 'LOS SEIS UNIDOS', 'RURAL', 0),
('0313', 'SANTA JUANA CARRO VIEJO', 'RURAL', 0),
('0314', 'COROZALITO', 'RURAL', 0),
('0315', 'LAS GARZAS', 'RURAL', 0),
('0316', 'AGUADA ABAJO', 'RURAL', 0),
('0317', 'APAMATE', 'RURAL', 0),
('0318', 'LAS DOS PALMAS', 'RURAL', 0),
('0319', 'JACOME ABAJO', 'RURAL', 0),
('0320', 'LAS CASITAS LA ROMANERA', 'RURAL', 0),
('0321', 'JACOME ARRIBA', 'RURAL', 0),
('0322', 'LAS ROSITAS MAHOMAL', 'RURAL', 0),
('0323', '12 DE OCTUBRE', 'URBANO', 0),
('0324', 'FORTALEZA REVOLUCIONARIA', 'URBANO', 0),
('0325', 'LOS BOLIVARIANOS', 'URBANO', 0),
('0326', 'SIMON BOLIVAR', 'URBANO', 0),
('0327', 'GUAMACHAL SANTA EDUVIGES', 'URBANO', 0),
('0328', 'BRISAS DE GUAMACHAL', 'URBANO', 0),
('0329', 'MAGISTERIO GUAMACHAL', 'URBANO', 0),
('0330', 'COROZAL', 'URBANO', 0),
('0331', 'LA LUISERA', 'URBANO', 0),
('0332', 'TERRAZAS DE COROZAL', 'URBANO', 0),
('0333', 'FRANCISCO DE MIRANDA', 'URBANO', 0),
('0334', 'LA VUELTA DEL CACHO', 'URBANO', 0),
('0335', 'LOMAS DEL LLANO', 'URBANO', 0),
('0336', 'LA VIGIA II', 'URBANO', 0),
('0337', 'LA VIGIA I', 'URBANO', 0),
('0338', 'ATASCOSA', 'URBANO', 0),
('0339', 'CASCO CENTRAL 6 EL DESPERTAR', 'URBANO', 0),
('0340', 'EL PARQUE', 'URBANO', 0),
('0341', 'TERRAZAS DEL PARQUE', 'URBANO', 0),
('0342', 'URBANIZACION MORICHAL', 'URBANO', 0),
('0343', 'LAS LOMAS', 'URBANO', 0),
('0344', 'RESIDENCIAS PAEZ', 'URBANO', 0),
('0345', 'PUEBLO NUEVO', 'URBANO', 0),
('0346', 'MARTILLO LOS CEDROS', 'RURAL', 0),
('0401', 'MORICHITO LA UNION', 'RURAL', 0),
('0402', 'MORICHALITO', 'RURAL', 0),
('0403', 'LA DORMIDA', 'RURAL', 0),
('0404', 'LAS BABITAS', 'RURAL', 0),
('0405', 'MAYALITO', 'RURAL', 0),
('0406', 'LOS ALGODONES', 'RURAL', 0),
('0407', 'RINCONOTE', 'RURAL', 0),
('0408', 'LOS VIVORALES', 'RURAL', 0),
('0409', 'COCO DE MONO', 'RURAL', 0),
('0410', 'MATA DE RANCHO', 'RURAL', 0),
('0411', 'LA QUINTA GRILLO', 'RURAL', 0),
('0412', 'LA CUMACA', 'RURAL', 0),
('0413', 'COCUIZA LA CONCEPCIÓN', 'RURAL', 0),
('0414', 'MAHOMITO', 'RURAL', 0),
('0415', 'MAMONAL CORCOBAO', 'RURAL', 0),
('0416', 'CARUTAL LA REPRESA', 'RURAL', 0),
('0417', 'LOS ISLEÑOS-CHUPADERO-EL CANO', 'RURAL', 0),
('0418', 'EL TRIUNFO', 'URBANO', 0),
('0419', 'LA CASCADA', 'URBANO', 0),
('0420', 'LAS AMAZONAS', 'URBANO', 0),
('0421', 'LOS BALSAMOS', 'URBANO', 0),
('0422', 'LOS CAMPITOS ', 'URBANO', 0),
('0423', 'RAFAEL VIDAL GUIA I', 'URBANO', 0),
('0424', 'RAFAEL VIDAL GUIA II ', 'URBANO', 0),
('0425', 'RAFAEL VIDAL GUIA III', 'URBANO', 0),
('0426', 'SIMON RODRIGUEZ', 'URBANO', 0),
('0427', 'VILLAS DEL SOL', 'URBANO', 0),
('0428', 'PARAISO REVOLUCIONARIO', 'URBANO', 0),
('0429', 'LAS INDUSTRIAS', 'URBANO', 0),
('0430', 'LAS CAROLINAS', 'URBANO', 0),
('0431', 'EL CORAZON DE DIOS', 'URBANO', 0),
('0432', 'ROMULO GALLEGOS', 'URBANO', 0),
('0433', 'EL MESIAS', 'URBANO', 0),
('0434', 'LA HACIENDITA', 'URBANO', 0),
('0435', 'LOS OLIVOS I', 'URBANO', 0),
('0436', 'LOS OLIVOS II', 'URBANO', 0),
('0437', 'BANCO OBRERO ', 'URBANO', 0),
('0438', 'LOS LAURELES', 'URBANO', 0),
('0439', 'MATOS CHARMELO', 'URBANO', 0),
('0440', 'CARLOS PEREZ I', 'URBANO', 0),
('0441', 'CARLOS PEREZ II', 'URBANO', 0),
('0442', 'CARLOS PEREZ III', 'URBANO', 0),
('0443', 'EL AMPARO', 'URBANO', 0),
('0444', 'CRISTO REY', 'URBANO', 0),
('0445', 'VIPEDI', 'URBANO', 0),
('0446', 'GUAICAIPURO', 'URBANO', 0),
('0447', 'POLIDEPORTIVO', 'URBANO', 0),
('0448', 'CASCO CENTRAL 7', 'URBANO', 0),
('0449', 'ACAPRAL LAS AGUADAS', 'RURAL', 0),
('0450', 'ARACAY ARRIBA', 'RURAL', 0),
('0451', 'ARENOSA, MEREYAL, EL TABACO', 'RURAL', 0),
('0452', 'BANCO TELESFERO', 'RURAL', 0),
('0453', 'CANDELARIA RABANAL ABAJO LAS PIÑAS', 'RURAL', 0),
('0454', 'CARTANAL LAS RAICES', 'RURAL', 0),
('0455', 'CUCHARITO', 'RURAL', 0),
('0456', 'EL GUARO', 'RURAL', 0),
('0457', 'EL PALITO', 'RURAL', 0),
('0458', 'ESPINO I', 'RURAL', 0),
('0459', 'ESPINO II ', 'RURAL', 0),
('0460', 'IGUANA', 'RURAL', 0),
('0461', 'LA ESE ', 'RURAL', 0),
('0462', 'LA MESA DE RABANAL', 'RURAL', 0),
('0463', 'LA MUERTA COLOMBIA', 'RURAL', 0),
('0464', 'LA PEÑA', 'RURAL', 0),
('0465', 'LA PREFERIDA MATA LINDA ', 'RURAL', 0),
('0466', 'LA TORTUGA', 'RURAL', 0),
('0467', 'LAS AGUADITAS', 'RURAL', 0),
('0468', 'LAS CALIFORNIAS', 'RURAL', 0),
('0469', 'LLORA LLORA', 'RURAL', 0),
('0470', 'LOS CAÑITOS ', 'RURAL', 0),
('0471', 'LOS GOLPES SAN FELIX', 'RURAL', 0),
('0472', 'MANIRITO EL PERRO', 'RURAL', 0),
('0473', 'RABANAL ABAJO', 'RURAL', 0),
('0474', 'SALAITO IGUANA NORTE', 'RURAL', 0),
('0475', 'SANTIAGO', 'RURAL', 0),
('0476', 'SANTO DOMINGO', 'RURAL', 0),
('0477', 'SIMAPIRE PRODUCTIVO', 'RURAL', 0),
('0478', 'ZANJONOTE DE ESPINO', 'RURAL', 0),
('0479', 'PARMANA', 'RURAL', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `donaciones`
--

CREATE TABLE `donaciones` (
  `id_donac` int(10) NOT NULL,
  `codi_donac` int(10) NOT NULL,
  `id_benef` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `asun_donac` varchar(80) COLLATE utf8_spanish_ci NOT NULL,
  `desc_donac` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `id_cat` varchar(5) COLLATE utf8_spanish_ci NOT NULL,
  `estat_donac` varchar(10) COLLATE utf8_spanish_ci NOT NULL DEFAULT 'Activo',
  `solic_donac` date NOT NULL,
  `cierr_donac` date NOT NULL,
  `id_usua` varchar(8) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `donaciones`
--

INSERT INTO `donaciones` (`id_donac`, `codi_donac`, `id_benef`, `asun_donac`, `desc_donac`, `id_cat`, `estat_donac`, `solic_donac`, `cierr_donac`, `id_usua`) VALUES
(1, 1, '10975000', 'PRIMERA DONACIÓN', 'PRIMERA DONACIÓN', '1001', 'Activo', '2023-07-01', '2023-07-31', 'ADMIN'),
(0, 1, '1485012', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 2, '5333866', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 3, '1484421', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 4, '4833836', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 5, '345946', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 6, '24619637', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 7, '32604014', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 8, '19964235', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 9, '32307291', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 10, '4308949', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 11, '30153399', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 12, '26299248', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 13, '26', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 14, '26464707', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 15, '9918267', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 16, '10982453', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 17, '2392729', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 18, '2395812', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 19, '13680610', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 20, '32075179', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 21, '28292539', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 22, '9918335', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 23, '1482314', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 24, '26299404', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 25, '20261067', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 26, '21313334', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 27, '31575812', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 28, '30152846', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 29, '4307229', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 30, '4833765', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 31, '2749434', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 32, '3641262', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 33, '18895124', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 34, '21312247', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 35, '30264415', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 36, '5622122', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 37, '19361327', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 38, '1472089', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 39, '9817936', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 40, '28292532', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 41, '4800190', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 42, '8796462', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 43, '8796978', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 44, '8560340', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 45, '3639190', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 46, '3991648', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 47, '3218236', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 48, '3951355', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 49, '792662', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 50, '4799301', '', '', '01006', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 51, '1485012', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 52, '5333866', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 53, '1484421', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 54, '4833836', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 55, '345946', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 56, '24619637', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 57, '32604014', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 58, '19964235', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 59, '32307291', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 60, '4308949', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 61, '30153399', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 62, '26299248', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 63, '26', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 64, '26464707', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 65, '9918267', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 66, '10982453', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 67, '2392729', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 68, '2395812', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 69, '13680610', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 70, '32075179', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 71, '28292539', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 72, '9918335', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 73, '1482314', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 74, '26299404', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 75, '20261067', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 76, '21313334', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 77, '31575812', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 78, '30152846', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 79, '4307229', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 80, '4833765', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 81, '2749434', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 82, '3641262', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 83, '18895124', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 84, '21312247', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 85, '30264415', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 86, '5622122', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 87, '19361327', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 88, '1472089', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 89, '9817936', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 90, '28292532', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 91, '4800190', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 92, '8796462', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 93, '8796978', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 94, '8560340', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 95, '3639190', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 96, '3991648', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 97, '3218236', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 98, '3951355', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 99, '792662', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', ''),
(0, 100, '4799301', '', '', '02001', 'Iniciado', '0000-00-00', '0000-00-00', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados`
--

CREATE TABLE `estados` (
  `id_estado` int(2) NOT NULL,
  `deno_estado` varchar(16) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `estados`
--

INSERT INTO `estados` (`id_estado`, `deno_estado`) VALUES
(1, 'DISTRITO CAPITAL'),
(2, 'AMAZONAS'),
(3, 'ANZOATEGUI'),
(4, 'APURE'),
(5, 'ARAGUA'),
(6, 'BARINAS'),
(7, 'MIRANDA'),
(8, 'CARABOBO'),
(9, 'COJEDES'),
(10, 'DELTA AMACURO'),
(11, 'FALCON'),
(12, 'GUARICO'),
(13, 'LARA'),
(14, 'MERIDA'),
(15, 'BOLIVAR'),
(16, 'MONAGAS'),
(17, 'NUEVA ESPARTA'),
(18, 'PORTUGUESA'),
(19, 'SUCRE'),
(20, 'TACHIRA'),
(21, 'TRUJILLO'),
(22, 'YARACUY'),
(23, 'ZULIA'),
(24, 'VARGAS'),
(25, 'D. FEDERALES');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sectores`
--

CREATE TABLE `sectores` (
  `id_sector` int(4) NOT NULL,
  `deno_sector` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `sectores`
--

INSERT INTO `sectores` (`id_sector`, `deno_sector`) VALUES
(1, 'CORAZON DE DIOS'),
(2, 'EL MESIAS'),
(3, ' LA BENDICION DE DIOS'),
(4, 'LA ROMANA '),
(5, 'LA MARGARITA'),
(6, 'BRISAS DEL NORTE'),
(7, 'VAPORON'),
(8, 'SIMON RODRIGUEZ'),
(9, 'EL TRIUNFO'),
(10, 'LAS MALVINAS'),
(11, 'LA VUELTA DEL CACHO'),
(12, 'FRANCISCO DE MIRANDA'),
(13, 'AREVALO CEDEÑO'),
(14, 'LIRIO DEL VALLE'),
(15, 'COLINA DEL VALLE'),
(16, '4 DE FEBRERO'),
(17, 'BRISAS DEL ESTE'),
(18, 'LOMAS DEL ESTE'),
(19, 'LOS OLIVOS I'),
(20, 'LOS OLIVOS II'),
(21, 'MATOS CHARMELO'),
(22, '5 DE JULIO'),
(23, 'PLAYA VERDE'),
(24, 'LA CONCORDIA'),
(25, 'LOS BALSAMOS'),
(26, 'LAS AMAZONAS'),
(27, 'SAN MIGUEL'),
(28, 'ALFALLANO'),
(29, 'EL ROSARIO'),
(30, 'EL ZAMURO'),
(31, 'LA MORITA'),
(32, 'SANTA EDUVIRGES'),
(33, 'MINAS DE ARENA'),
(34, 'MATADERO'),
(35, 'AEROPUERTO'),
(36, 'LA AGUSTINA'),
(37, 'AUTOCONSTRUCCION I'),
(38, 'AUTOCONSTRUCCION II'),
(39, 'UNIVERSIDAD'),
(40, 'JOSE FELIX RIBAS'),
(41, 'LA REPRESA'),
(42, 'LA FLORIDA I'),
(43, 'FLORIDA II'),
(44, 'PARAISO'),
(45, 'LAS INDUSTRIAS'),
(46, 'POLIDEPORTIVO'),
(47, 'CARLOS PEREZ'),
(48, 'PUEBLO NUEVO'),
(49, 'CALLE NUEVA'),
(50, 'LA VIGIA II'),
(51, 'LA VIGIA I'),
(52, 'COCACOLA'),
(53, '12 DE OCTUBRE'),
(54, 'ROMULO GALLEGOS'),
(55, 'EL MARTILLO'),
(56, 'LA ATASCOSA '),
(57, 'CASCO CENTRAL '),
(58, 'SIMON BOLIVAR'),
(59, 'LAS GARCITAS'),
(60, 'PADRE CHACIN'),
(61, 'CORAZON DE JESUS'),
(62, 'LOS COCOS'),
(63, 'JARDIN LA PASCUA'),
(64, 'LA PUA'),
(65, 'RUIZ PINEDA'),
(66, 'LAS MARGARITAS'),
(67, 'EL FARALYON'),
(68, 'ALBORADA CONTRY'),
(69, 'VILLAS DE SOL'),
(70, 'BANCO OBRERO'),
(71, 'VIDAL GUIA I'),
(72, 'VIDAL GUIA II'),
(73, 'VIDAL GUIA III'),
(74, 'LAS CASCADA'),
(75, 'EL PARQUE'),
(76, 'TERRAZAS DEL PARQUE'),
(77, 'MORICHAL'),
(78, 'LOS BOLIVARIANOS'),
(79, 'TERRAZA DE HUGO CHAVEZ'),
(80, 'OCV LA CANDELARIA'),
(81, 'LA TRINIDAD'),
(82, 'LA GRACIA DE DIOS'),
(83, 'MARIA DE SAN JOSE'),
(84, 'PALMAR I'),
(85, 'PALMAR II'),
(86, 'PALMAR III'),
(87, 'CERRITO I'),
(88, 'CERRITO II'),
(89, 'CERRITO III'),
(90, 'RODRIGUEZ CHACIN'),
(91, 'EL REMANSO'),
(92, 'FRENTE AL AMPARO'),
(93, 'ALTO DE LOS REYES'),
(94, 'LAS CAROLINAS'),
(95, 'LOS LAURELES'),
(96, 'CRISTO REY'),
(97, 'VIPEDI'),
(98, 'LAS LOMAS'),
(99, 'LOMAS DEL LLANOS II'),
(100, 'GUAMACHAL'),
(101, 'LA ARBOLEDA'),
(102, 'TERRAZA DE COROZAL'),
(103, 'LLANO ALTO'),
(104, 'FOGONCITO'),
(105, 'LA BENDICION'),
(106, 'TAMANACO CONTRY'),
(107, 'VILLA DEL ROSARIO'),
(108, 'LA TRES GRACIAS'),
(109, 'LAS AVES'),
(110, 'LA SOLUCION'),
(111, 'TERRAZA DE EL LIDO'),
(112, 'VILLA SHALOM'),
(113, 'VILLAS DE PLATA'),
(114, 'LOS CHAGUARAMOS'),
(115, 'EL AMPARO'),
(116, 'LAS VILLAS'),
(117, 'PALMA REAL'),
(118, 'LOMAS DEL LLANOS'),
(119, 'LOMAS DEL LLANOS V'),
(120, 'CONJ. RES.GUAMACHAL MEIN'),
(121, 'CONJ. RES.GUAMACHAL 1'),
(122, 'CONJ. RES.GUAMACHAL II'),
(123, 'CONJ. VILLAS DEL VALLE'),
(124, 'VILLA CERRITO'),
(125, 'VALLE FRESCO'),
(126, 'VILLA SHARON'),
(127, 'VILLA VIRGEN DEL VALLE'),
(128, 'VILLAS LA PASCUA'),
(129, 'CONJUNTO RESIDENCIAL GUAMACHAL (ARBOLEDA)'),
(130, 'CONJUNTO RESIDENCIAL VIPEDI II'),
(131, 'CONJUNTO RESIDENCIAL PAEZ'),
(132, 'CONJUNTO RESIDENCIAL  5 DE JULIO'),
(133, 'CONJUNTO RESIDENCIAL LA FUENTE');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_usua` varchar(8) COLLATE utf8_spanish_ci NOT NULL,
  `clave_usua` varchar(8) COLLATE utf8_spanish_ci NOT NULL,
  `nomb_usua` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `apell_usua` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `rol_usua` varchar(10) COLLATE utf8_spanish_ci NOT NULL DEFAULT 'USUARIO',
  `estat_usua` varchar(10) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usua`, `clave_usua`, `nomb_usua`, `apell_usua`, `rol_usua`, `estat_usua`) VALUES
('admin', 'admin', 'Administrador', 'Administrador', 'USUARIO', 'Activo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumno`
--
ALTER TABLE `alumno`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `consejoc`
--
ALTER TABLE `consejoc`
  ADD PRIMARY KEY (`codi_consc`);

--
-- Indices de la tabla `estados`
--
ALTER TABLE `estados`
  ADD PRIMARY KEY (`id_estado`);

--
-- Indices de la tabla `sectores`
--
ALTER TABLE `sectores`
  ADD PRIMARY KEY (`id_sector`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alumno`
--
ALTER TABLE `alumno`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
