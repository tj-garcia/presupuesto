<?php 
/**
* 
INSERT INTO donaciones (codi_donac, id_benef, id_cat, estat_donac) SELECT table10.codi_donac, table10.id_benef, table10.id_cat, table10.estat_donac FROM table10
UPDATE donaciones SET donaciones.id_cat = "02001" WHERE donaciones.id_cat = "2001"
UPDATE table1 AS t1 INNER JOIN table2 AS t2  on t1.id = t2.id SET t1.valor = concat(t1.valor, ' ', t2.valor) WHERE  t1.id > 1;
UPDATE consejoc SET consejoc.codi_consc = concat('0', consejoc.codi_consc)
*/
class Donaciones
{
	private $id;
	private $codigo;
	private $benef;
	private $asunto;
	private $descripcion;
	private $categoria;
	private $estatus;
	private $solicitud;
	private $cierre;
	private $usuario;

	
	function __construct($id,$codigo,$benef,$asunto,$descripcion,$categoria,$estatus,$solicitud,$cierre,$usuario)
	{
		$this->setId($id);
		$this->setCodigo($codigo);
		$this->setBenef($benef);
		$this->setAsunto($asunto);
		$this->setDescripcion($descripcion);
		$this->setCategoria($categoria);
		$this->setEstatus($estatus);	
		$this->setSolicitud($solicitud);
		$this->setCierre($cierre);			
		$this->setUsuario($usuario);
	}

	public function getId(){
		return $this->id;
	}

	public function setId($id){
		$this->id = $id;
	}

	public function getCodigo(){
		return $this->codigo;
	}

	public function setCodigo($codigo){
		$this->id = $codigo;
	}

	public function getBenef(){
		return $this->benef;
	}

	public function setBenef($benef){
		$this->benef = $benef;
	}

	public function getAsunto(){
		return $this->asunto;
	}

	public function setAsunto($asunto){
		$this->asunto = $asunto;
	}

	public function getDescripcion(){
		return $this->descripcion;
	}

	public function setDescripcion($descripcion){
		$this->descripcion = $descripcion;
	}

	public function getCategoria(){
		return $this->categoria;
	}

	public function setCategoria($categoria){
		$this->categoria = $categoria;
	}

	public function getEstatus(){
		return $this->estatus;
	}

	public function setEstatus($estatus){
        $this->estatus = $estatus;
	}

	public function getSolicitud(){
		return $this->solicitud;
	}

	public function setSolicitud($solicitud){
		$this->solicitud = $solicitud;
	}

	public function getCierre(){
		return $this->cierre;
	}

	public function setCierre($cierre){
		$this->cierre = $cierre;
	}

	public function getUsuario(){
		return $this->usuario;
	}

	public function setUsuario($usuario){
		$this->usuario = $usuario;
	}


	public static function save($Donaciones){
		$db=Db::getConnect();
		//var_dump($beneficiario);
		//die();              
                                                                     
		$insert=$db->prepare('INSERT INTO donaciones VALUES (:id, :codigo, :benef,:asunto,:descripcion, :categoria, :estatus, :solicitud, :cierre, :usuario)');
		$insert->bindValue('id',$Donaciones->getId());
		$insert->bindValue('codigo',$Donaciones->getCodigo());
		$insert->bindValue('benef',$Donaciones->getBenef());
		$insert->bindValue('asunto',$Donaciones->getAsunto());
		$insert->bindValue('descripcion',$Donaciones->getDescripcion());
		$insert->bindValue('categoria',$Donaciones->getCategoria());
		$insert->bindValue('estatus',$Donaciones->getEstatus());
		$insert->bindValue('solicitud',$Donaciones->getSolicitud());
		$insert->bindValue('cierre',$Donaciones->getCierre());
		$insert->bindValue('usuario',$Donaciones->getUsuario());
		$insert->execute();
	}

	public static function list1(){
		$db=Db::getConnect();
		$listaAyudas=[];

		$select=$db->query('SELECT donaciones.codi_donac, beneficiario.id_benef,beneficiario.nombres, categorias.deno_cat, donaciones.estat_donac FROM donaciones INNER JOIN beneficiario ON donaciones.id_benef=beneficiario.id_benef INNER JOIN categorias ON donaciones.id_cat=categorias.id_cat order by donaciones.codi_donac');
        //capturar el array y presentar los datos. No  llamar a la clase, al parecer no hace falta ojo   
		foreach($select->fetchAll() as $ayudas){
			//$listaAyudas[]=new Ayudas($ayudas['id_ayudas'],$ayudas['nombres'],$ayudas['deno_cat'],$ayudas['estat_ayud']);
			$listaAyudas[]= array('id' => $ayudas['codi_donac'],'cedula' =>$ayudas['id_benef'],'nombres' =>$ayudas['nombres'],'categoria' =>$ayudas['deno_cat'],'estatus' =>$ayudas['estat_donac']);
		}            
		return $listaAyudas;
	}

	public static function all(){
		$db=Db::getConnect();
		$listaDonaciones=[];

		$select=$db->query('SELECT * FROM donaciones order by codi_donac');

		foreach($select->fetchAll() as $registro){
			$listaDonaciones[]=new Donaciones($registro['id_donac'],$registro['codi_donac'],$registro['id_benef'],$registro['asun_donac'],$registro['desc_donac'],$registro['id_cat'],$registro['estat_donac'],$registro['solic_donac'],$registro['cierre'],$registro['id_donac']);
		}            
		return $listaDonaciones;
	}

	public static function searchById($id){
		$db=Db::getConnect();
		$select=$db->prepare('SELECT * FROM donaciones WHERE codi_donac=:id');
		$select->bindValue('id',$id);
		$select->execute();

		$registro=$select->fetch();
		if (!empty($registro['id_donac'])) {
		   $listaDonaciones = new Donaciones ($registro['id_donac'],$registro['codi_donac'],$registro['id_benef'],$registro['asun_donac'],$registro['desc_donac'],$registro['id_cat'],$registro['estat_donac'],$registro['solic_donac'],$registro['cierre'],$registro['id_donac']);
			//var_dump($listaDonaciones);
			//die();
			
		} else {
			$listaDonaciones = new Donaciones("","","","","","","","","","");
		}
		return $listaDonaciones;
	}

	public static function update($donaciones){
		$db=Db::getConnect();
		$update=$db->prepare('UPDATE donaciones SET id_benef=:benef, asun_donac=:asunto, desc_donac=:descripcion, id_cat=:categoria, estat_donac=:estatus, solic_donac=:solicitud, cierr_donac=:cierre, id_usua=:usuario WHERE id_donac=:codigo');
		$insert->bindValue('benef',$donaciones->getBenef());
		$insert->bindValue('asunto',$donaciones->getAsunto());
		$insert->bindValue('descripcion',$donaciones->getDescripcion());
		$insert->bindValue('categoria',$donaciones->getCategoria());
		$insert->bindValue('estatus',$donaciones->getEstatus());
		$insert->bindValue('solicitud',$donaciones->getSolicitud());
		$insert->bindValue('cierre',$donaciones->getCierre());
		$insert->bindValue('usuario',$donaciones->getUsuario());
		$insert->bindValue('codigo',$donaciones->getCodigo());
		$update->execute();

	}

	public static function delete($id){
		$db=Db::getConnect();
		$delete=$db->prepare('DELETE  FROM donaciones WHERE codi_donac=:id');
		$delete->bindValue('id',$id);
		$delete->execute();		
	}
}

?>