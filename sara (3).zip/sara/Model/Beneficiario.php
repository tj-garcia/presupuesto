<?php 
/**
* 
*/
class Beneficiario
{
	private $id;
	private $nombres;
	private $apellidos;
	private $telefono;
	private $ciudad;
	private $estado;
	private $sector;
	private $direccion;
	private $estatus;  /* estatus del beneficiario */
	private $ayudas;  /* cantidad ayudas recibidas */

	
	function __construct($id, $nombres,$apellidos, $telefono, $ciudad, $estado, $sector, $direccion, $estatus, $ayudas)
	{
		$this->setId($id);
		$this->setNombres($nombres);
		$this->setApellidos($apellidos);
		$this->setTelefono($telefono);
		$this->setCiudad($ciudad);
		$this->setEstado($estado);	
		$this->setSector($sector);
		$this->setDireccion($direccion);			
		$this->setEstatus($estatus);
		$this->setAyudas($ayudas);
	}

	public function getId(){
		return $this->id;
	}

	public function setId($id){
		$this->id = $id;
	}

	public function getNombres(){
		return $this->nombres;
	}

	public function setNombres($nombres){
		$this->nombres = $nombres;
	}

	public function getApellidos(){
		return $this->apellidos;
	}

	public function setApellidos($apellidos){
		$this->apellidos = $apellidos;
	}

	public function getTelefono(){
		return $this->telefono;
	}

	public function setTelefono($telefono){
		$this->telefono = $telefono;
	}

	public function getCiudad(){
		return $this->ciudad;
	}

	public function setCiudad($ciudad){
		$this->ciudad = $ciudad;
	}

	public function getEstado(){

		return $this->estado;
	}

	public function setEstado($estado){
        $this->estado = $estado;

	}

	public function getSector(){
		return $this->sector;
	}

	public function setSector($sector){
		$this->sector = $sector;
	}

	public function getDireccion(){
		return $this->direccion;
	}

	public function setDireccion($direccion){
		$this->direccion = $direccion;
	}

	public function getEstatus(){
		return $this->estatus;
	}

	public function setEstatus($estatus){
		$this->estatus = $estatus;
	}
	public function getAyudas(){
		return $this->ayudas;
	}

	public function setAyudas($ayudas){
		$this->ayudas = $ayudas;
	}



	public static function save($beneficiario){
		$db=Db::getConnect();
		//var_dump($beneficiario);
		//die();              
                                                                     
		$insert=$db->prepare('INSERT INTO beneficiario VALUES (:id, :nombres,:apellidos,:telefono, :ciudad, :estado, :sector, :direccion, :estatus, :ayudas)');
		$insert->bindValue('id',$beneficiario->getId());
		$insert->bindValue('nombres',$beneficiario->getNombres());
		$insert->bindValue('apellidos',$beneficiario->getApellidos());
		$insert->bindValue('telefono',$beneficiario->getTelefono());
		$insert->bindValue('ciudad',$beneficiario->getCiudad());
		$insert->bindValue('estado',$beneficiario->getEstado());
		$insert->bindValue('sector',$beneficiario->getSector());
		$insert->bindValue('direccion',$beneficiario->getDireccion());
		$insert->bindValue('estatus',$beneficiario->getEstatus());
		$insert->bindValue('ayudas',$beneficiario->getAyudas());
		$insert->execute();
	}

	public static function all(){
		$db=Db::getConnect();
		$listaBeneficiarios=[];

		$select=$db->query('SELECT * FROM beneficiario order by id_benef');

		foreach($select->fetchAll() as $beneficiario){
			$listaBeneficiarios[]=new Beneficiario($beneficiario['id_benef'],$beneficiario['nombres'],$beneficiario['apellidos'],$beneficiario['telefono'],$beneficiario['ciudad'],$beneficiario['id_estado'],$beneficiario['sector'],$beneficiario['direccion'],$beneficiario['estatus'],$beneficiario['ayudas']);
		}            
		return $listaBeneficiarios;
	}

	public static function searchById($id){
		$db=Db::getConnect();
		$select=$db->prepare('SELECT * FROM beneficiario WHERE id_benef=:id');
		$select->bindValue('id',$id);
		$select->execute();

		$beneficiario=$select->fetch();
		if (!empty($beneficiario['id'])) {
		   $beneficiario2 = new Beneficiario ($beneficiario['id_benef'],$beneficiario['nombres'],$beneficiario['apellidos'],$beneficiario['telefono'],$beneficiario['ciudad'],$beneficiario['id_estado'],$beneficiario['sector'],$beneficiario['direccion'],$beneficiario['estatus'],$beneficiario['ayudas']);
			//echo "Epa.. ". var_dump($usuarioDb)."epa2";
			//var_dump($usuario);
			//die();
			
		} else {
			$beneficiario2 = new Beneficiario("","","","","","","","","","");
		}
		return $beneficiario2;
	}

	public static function update($beneficiario){
		$db=Db::getConnect();
		$update=$db->prepare('UPDATE beneficiario SET nombres=:nombres, apellidos=:apellidos, telefono=:telefono, ciudad=:ciudad, estado=:estado, estatus=:estatus, ayudas=:ayudas WHERE id_benef=:id');
		$update->bindValue('nombres',$beneficiario->getNombres());
		$update->bindValue('apellidos',$beneficiario->getApellidos());
	    $update->bindValue('telefono',$beneficiario->getTelefono());
		$update->bindValue('ciudad',$beneficiario->getCiudad());
		$update->bindValue('estado',$beneficiario->getEstado());
		$update->bindValue('sector',$beneficiario->getSector());
		$update->bindValue('direccion',$beneficiario->getDireccion());
		$update->bindValue('estatus',$beneficiario->getEstatus());
		$update->bindValue('ayudas',$beneficiario->getAyudas());
		$update->bindValue('id',$beneficiario->getId());
		$update->execute();

	}

	public static function delete($id){
		$db=Db::getConnect();
		$delete=$db->prepare('DELETE  FROM beneficiario WHERE id_benef=:id');
		$delete->bindValue('id',$id);
		$delete->execute();		
	}
}

?>