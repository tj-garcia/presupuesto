<link rel="stylesheet" href="assets/DataTables/datatables.css" />
<!-- <link rel="stylesheet" href="assets/css/bootstrap-icons.min.css" /> -->
	<h2>Lista Beneficiarios</h2>
    <!--
	<form class="form-inline form-signin" action="?controller=alumno&action=search" method="post">
		<div class="form-group row">
			<div class="col-xs-4">
				<input class="form-control" id="id" name="id" type="text" placeholder="Busqueda por ID">
			</div>
		</div>
		<div class="form-group row">
			<div class="col-xs-4">
				<button type="submit" class="btn btn-primary" ><span class="glyphicon glyphicon-search"> </span> Buscar</button>
			</div>
		</div>
	</form>
-->
	<div class="table-responsive form-signin">
		<table class="table table-striped" id="tabla1"> <!--table table-hover-->
			<thead>
				<tr>
					<th>C&eacute;dula</th>
					<th>Nombres</th>
					<th>Apellidos</th>
					<th>Estatus</th>
					<th>Accion</th>
					<th>Accion2</th>
				</tr>
				<tbody>
					<?php foreach ($listaBeneficiarios as $beneficiario) {?>

					
					<tr>
						<td> <a href="?controller=alumno&&action=updateshow&&idAlumno=<?php  echo $beneficiario->getId()?>"> <?php echo $beneficiario->getId(); ?></a> </td>
						<td><?php echo $beneficiario->getNombres(); ?></td>
						<td><?php echo $beneficiario->getApellidos(); ?></td>
						<td><?php echo $beneficiario->getEstatus(); ?></td>
						<td><a href="?controller=alumno&&action=delete&&id=<?php echo $beneficiario->getId() ?>">Eliminar</a><i class="bi-alarm-clock"></i> </td>

						<td>
							<!--<button class="btn btn-primary" data-title="Edit" data-toggle="modal" data-target="#edit" ><span class="bi-alarm"></span><span class="bi-trash3"></span><i class="bi bi-shield-plus"></i><i class="bi bi-pencil-fill"></i></button> -->
							<button class="btn btn-outline-primary btn-sm"  ><i class="bi bi-shield-plus"></i></button>
							<button class="btn btn-outline-primary btn-sm" data-title="Edit" data-toggle="modal" data-target="#edit" ><i class="bi bi-pencil-fill"></i></button>
							<button class="btn btn-primary btn-sm" data-title="Edit" data-toggle="modal" data-target="#edit" ><i class="bi-trash3"></i></button>
							<button class="btn btn-primary btn-sm" data-title="Edit" data-toggle="modal" data-target="#edit" ><i class="bi-alarm"></i></button>
						</td>
					</tr>
					<?php } ?>
				</tbody>

			</thead>
		</table>

	</div>	

<script src="assets/DataTables/datatables.js"></script>
<script>
$(document).ready( function () {
$('#tabla1').DataTable({
	responsive: true ,
    "language": {
      "url": "assets/DataTables/es-ES.json"
    }
  });
} );
</script>