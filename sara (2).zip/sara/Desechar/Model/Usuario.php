<?php 
/**
* 
*/
class Usuario
{
	private $id;
	private $nombres;
	private $apellidos;
	private $estado;
	private $clave;

	
	function __construct($id, $nombres,$apellidos, $estado, $clave)
	{
		$this->setId($id);
		$this->setNombres($nombres);
		$this->setApellidos($apellidos);
		$this->setEstado($estado);		
		$this->setClave($clave);
	}

	public function getId(){
		return $this->id;
	}

	public function setId($id){
		$this->id = $id;
	}

	public function getNombres(){
		return $this->nombres;
	}

	public function setNombres($nombres){
		$this->nombres = $nombres;
	}

	public function getApellidos(){
		return $this->apellidos;
	}

	public function setApellidos($apellidos){
		$this->apellidos = $apellidos;
	}

	public function getEstado(){

		return $this->estado;
	}

	public function setEstado($estado){
		
		if (strcmp($estado, 'on')==0) {
			$this->estado=1;
		} elseif(strcmp($estado, '1')==0) {
			$this->estado='checked';
		}elseif (strcmp($estado, '0')==0) {
			$this->estado='of';
		}else {
			$this->estado=0;
		}

	}

	public function getClave(){
		return $this->clave;
	}	

	public function setClave($clave){
		$this->clave = $clave;
	}

	public static function save($Usuario){
		$db=Db::getConnect();
		//var_dump($alumno);
		//die();
		

		$insert=$db->prepare('INSERT INTO usuario VALUES (:id, :nombres,:apellidos,:estado,:clave)');
		$insert->bindValue('id',$Usuario->getId());
		$insert->bindValue('nombres',$Usuario->getNombres());
		$insert->bindValue('apellidos',$Usuario->getApellidos());
		$insert->bindValue('estado',$Usuario->getEstado());
		$insert->bindValue('clave',$Usuario->getClave());
		$insert->execute();
	}

	public static function all(){
		$db=Db::getConnect();
		$listaUsuarios=[];

		$select=$db->query('SELECT * FROM usuario order by id');

		foreach($select->fetchAll() as $usuario){
			$listaUsuarios[]=new Usuario($usuario['id'],$usuario['nombres'],$usuario['apellidos'],$usuario['estado'],$usuario['clave']);
		}
		return $listaUsuarios;
	}

	public static function searchById($id){
		$db=Db::getConnect();
		$select=$db->prepare('SELECT * FROM usuario WHERE id=:id');
		$select->bindValue('id',$id);
		$select->execute();

		$usuarioDb=$select->fetch();

		if (!empty($usuarioDb['id'])) {
			$usuario = new Usuario ($usuarioDb['id'],$usuarioDb['nombres'], $usuarioDb['apellidos'], $usuarioDb['estado'], $usuarioDb['clave']);
			//echo "Epa.. ". var_dump($usuarioDb)."epa2";
			//var_dump($usuario);
			//die();
			
		} else {
			$usuario = new Usuario("","","","","");
			
		}
        return $usuario;
	}

	public static function update($Usuario){
		$db=Db::getConnect();
		$update=$db->prepare('UPDATE usuario SET nombres=:nombres, apellidos=:apellidos, estado=:estado, clave=:clave WHERE id=:id');
		$update->bindValue('nombres', $Usuario->getNombres());
		$update->bindValue('apellidos',$Usuario->getApellidos());
		$update->bindValue('estado',$Usuario->getEstado());
		$update->bindValue('clave',$Usuario->getClave());
		$update->bindValue('id',$Usuario->getId());
		$update->execute();
	}

	public static function delete($id){
		$db=Db::getConnect();
		$delete=$db->prepare('DELETE  FROM usuario WHERE id=:id');
		$delete->bindValue('id',$id);
		$delete->execute();		
	}
}

?>