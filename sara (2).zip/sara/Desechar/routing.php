<?php
    require_once('connection.php');
    //echo "routing";  
	switch ($controller) {
		case 'login':
		     $controllers=array('login'=>['login','logout']);
		break;
		case 'default':
		     $controllers=array('default'=>['escritorio']);
		break;
		case 'beneficiario':
		     $controllers=array('beneficiario'=>['index','register','save','show','updateshow','update','delete','search','error','porcedula']);
		break;			
		case 'alumno':
		     $controllers=array('alumno'=>['index','register','save','show','updateshow','update','delete','search','error']);
		break;
		default:
				# code...
		break;
	}



	if (array_key_exists($controller,  $controllers)) {
		if (in_array($action, $controllers[$controller])) {
			call($controller, $action);
		}
		else{
			call('default','escritorio');
		}		
	}else{
		call('default','escritorio');
	}

	function call($controller, $action){
		if ($controller!='default') {
			require_once('Controllers/'.$controller.'Controller.php');
		}

		switch ($controller) {
			case 'default':
			//require_once('Model/Alumno.php');
			//$controller= new UsuarioController();
			require_once('Views/Layouts/escritorio.php');
			break;
			case 'login':
			     require_once('Model/Usuario.php');
			     $controller= new LoginController();
			     break;
			case 'alumno':
			     require_once('Model/Alumno.php');
			     $controller= new UsuarioController();
			     break;			
			case 'beneficiario':
			require_once('Model/Beneficiario.php');
			$controller= new BeneficiarioController();
			break;			
			default:
					# code...
			break;
		}
		if ($controller!='default') {
		$controller->{$action}();
	    }
	}
?>