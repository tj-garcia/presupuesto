<?php 
/**
* 
*/
//session_start();
class LoginController
{
	function __construct()
	{
		
	}

	function login(){
		if (!empty($_POST['usuario']) && !empty($_POST['clave'])  ) {
			$id=htmlentities($_POST['usuario']);
			$clave=htmlentities($_POST['clave']);
			$usuario=Usuario::searchById($id);
			//$listaUsuarios[]=$usuario;	
			//echo is_null($listaUsuarios['id']);  // 1 = true  0 = false
			if (strtoupper($usuario->getClave())===$clave && strtoupper($usuario->getId())===$id && empty($usuario->getId())===false ) {
              //session_start();				
			  //header("Location: index.php");
			  //	echo var_dump($listaUsuarios);
			  $_SESSION["mensaje"] = "";
			  $_SESSION["nombre"] = $usuario->getNombres();
			  unset($usuario);	
              require_once('Views/Layouts/menu.php');   
              require_once('Views/Layouts/escritorio.php');	
              require_once('Views/Layouts/pie.php');				
			  
			} else {
			  $_SESSION["mensaje"] = "Err-001: Error en Usuario o Clave";
			  header("Location: index.php");
			}
			//var_dump($id);
			//die();
		} else {
			  $_SESSION["mensaje"]="Err-002: Falta Usuario o Clave";
			  header("Location: index.php");
		}
	}
}
?>