<header>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><img class="mb-4 rounded-circle" src="assets/icon/cintillo.jpg" alt="" ></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse dropdown navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      	<!-- Opcion 1 menu -->
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#" onclick='SubmitForm("default","escritorio");'>Inicio</a>
        </li>
        <!-- Opcion 2 menu -->
        <li class="nav-item">
          <a class="nav-link" href="#">Enlace</a>
        </li>
        <!-- Opcion 3 menu -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Beneficiarios
          </a>
          <!-- Opcion 1 submenu -->
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="#" onclick='SubmitForm("beneficiario","register");'>Registro</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a  class="dropdown-item" href="#" onclick='SubmitForm("beneficiario","show");'>Listar</a></li>
          </ul>
        </li>
        <!-- Opcion 3 - 4 menu -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Donaciones
          </a>
          <!-- Opcion 1 submenu -->
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="#" onclick='SubmitForm("donaciones","porcedula");'>Registro</a></li>
            <li><a  class="dropdown-item" href="#" onclick='SubmitForm("donaciones","list1");'>Listar</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Algo más aquí</a></li>
          </ul>
        </li>
        <!-- Opcion 4 menu -->
        <li class="nav-item">
          <a class="nav-link disabled">Deshabilitado</a>
        </li>
      </ul>
      <?php //if ($controller=="default") { ?> 
      <form class="d-flex" role="search" name="form0" method="post" action="index.php">
        <input class="form-control me-2" type="search" placeholder="C&eacute;dula del Beneficiario" aria-label="Buscar" name="id">
        <button class="btn btn-outline-success" type="submit">Buscar</button>
        <input type="hidden" id="controller0" name="controller0" class="form-control" placeholder="" value="beneficiario">
        <input type="hidden" id="action0" name="action0" class="form-control" placeholder="" value="updateshow">
      </form>
      <?php //} ?>
    
    </div>
  </div>
</nav>
<br>
</header>