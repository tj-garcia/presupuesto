-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 04-07-2023 a las 13:03:48
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `crud`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumno`
--

CREATE TABLE `alumno` (
  `id` int(11) NOT NULL,
  `nombres` varchar(255) DEFAULT NULL,
  `apellidos` varchar(255) DEFAULT NULL,
  `estado` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `alumno`
--

INSERT INTO `alumno` (`id`, `nombres`, `apellidos`, `estado`) VALUES
(1, 'Elivar Oswaldo', 'Largo Rios', '1'),
(5, 'Juan', 'Vargas', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ayudas`
--

CREATE TABLE `ayudas` (
  `id_ayudas` int(9) NOT NULL,
  `id` int(9) NOT NULL,
  `id_cat` varchar(5) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `asun_ayud` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `desc_ayud` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `fSol__ayud` date NOT NULL,
  `fAdj_ayud` date NOT NULL,
  `estat_ayud` varchar(10) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `id_us` varchar(8) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `ayudas`
--

INSERT INTO `ayudas` (`id_ayudas`, `id`, `id_cat`, `asun_ayud`, `desc_ayud`, `fSol__ayud`, `fAdj_ayud`, `estat_ayud`, `id_us`) VALUES
(1, 10975000, '01001', 'SOLICITUD DE MEDICINAS', 'SOLICITUD DE MEDICINAS PARA VARIAS COSAS', '2023-07-03', '2023-07-31', 'ACTIVO', 'admin'),
(2, 30000000, '01002', 'SOLICITUD DE MULETAS', 'VARIAS MULETAS', '2023-07-01', '2023-07-31', 'ACTIVO', 'ADMIN');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `beneficiario`
--

CREATE TABLE `beneficiario` (
  `id` int(9) NOT NULL,
  `nombres` varchar(40) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(40) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(11) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `ciudad` varchar(40) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL DEFAULT 'VALLE DE LA PASCUA',
  `estado` int(2) NOT NULL DEFAULT 12,
  `sector` varchar(40) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `estatus` varchar(10) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `ayudas` int(3) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `beneficiario`
--

INSERT INTO `beneficiario` (`id`, `nombres`, `apellidos`, `telefono`, `ciudad`, `estado`, `sector`, `direccion`, `estatus`, `ayudas`) VALUES
(2000000, 'pedro jose', 'araujo escalona', '20', '20', 12, '20', 'direccion20', 'activo', 0),
(10000000, 'nombre', 'apellido', 'telefono', 'ciudad', 12, 'sector', 'direccion', 'activo', 0),
(10975000, 'ana', 'padron', '02353410000', 'valle de la pascua', 0, 'sector', 'calle 1 casa 2 sector 3', '', 0),
(30000000, 'treinta', 'treinta', '02353000000', 'valle de la pascua', 12, 'sector', 'direccion', 'activo', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id_cat` varchar(5) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `deno_cat` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `ay_sol_cat` int(7) NOT NULL,
  `ay_aprob_cat` int(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id_cat`, `deno_cat`, `ay_sol_cat`, `ay_aprob_cat`) VALUES
('01000', 'MEDICINAS', 0, 0),
('01001', 'COMPRA MEDICINAS', 0, 0),
('01002', 'PAGO CONSULTA', 0, 0),
('01003', 'EXÁMENES MÉDICOS', 0, 0),
('01004', 'BASTONES', 0, 0),
('01005', 'MULETAS', 0, 0),
('01006', 'SILLA DE RUEDAS', 0, 0),
('02000', 'ALIMENTOS', 0, 0),
('02001', 'COMPRA ALIMENTOS', 0, 0),
('03000', 'VIVIENDA', 0, 0),
('03001', 'ADJUDICACION DE VIVIENDA', 0, 0),
('03002', 'REPARACIONES', 0, 0),
('03004', 'MATERIALES', 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados`
--

CREATE TABLE `estados` (
  `id_estado` int(2) NOT NULL,
  `deno_estado` varchar(16) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `estados`
--

INSERT INTO `estados` (`id_estado`, `deno_estado`) VALUES
(1, 'DISTRITO CAPITAL'),
(2, 'AMAZONAS'),
(3, 'ANZOATEGUI'),
(4, 'APURE'),
(5, 'ARAGUA'),
(6, 'BARINAS'),
(7, 'MIRANDA'),
(8, 'CARABOBO'),
(9, 'COJEDES'),
(10, 'DELTA AMACURO'),
(11, 'FALCON'),
(12, 'GUARICO'),
(13, 'LARA'),
(14, 'MERIDA'),
(15, 'BOLIVAR'),
(16, 'MONAGAS'),
(17, 'NUEVA ESPARTA'),
(18, 'PORTUGUESA'),
(19, 'SUCRE'),
(20, 'TACHIRA'),
(21, 'TRUJILLO'),
(22, 'YARACUY'),
(23, 'ZULIA'),
(24, 'VARGAS'),
(25, 'D. FEDERALES');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sectores`
--

CREATE TABLE `sectores` (
  `id_sector` int(4) NOT NULL,
  `deno_sector` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `sectores`
--

INSERT INTO `sectores` (`id_sector`, `deno_sector`) VALUES
(1, 'CORAZON DE DIOS'),
(2, 'EL MESIAS'),
(3, ' LA BENDICION DE DIOS'),
(4, 'LA ROMANA '),
(5, 'LA MARGARITA'),
(6, 'BRISAS DEL NORTE'),
(7, 'VAPORON'),
(8, 'SIMON RODRIGUEZ'),
(9, 'EL TRIUNFO'),
(10, 'LAS MALVINAS'),
(11, 'LA VUELTA DEL CACHO'),
(12, 'FRANCISCO DE MIRANDA'),
(13, 'AREVALO CEDEÑO'),
(14, 'LIRIO DEL VALLE'),
(15, 'COLINA DEL VALLE'),
(16, '4 DE FEBRERO'),
(17, 'BRISAS DEL ESTE'),
(18, 'LOMAS DEL ESTE'),
(19, 'LOS OLIVOS I'),
(20, 'LOS OLIVOS II'),
(21, 'MATOS CHARMELO'),
(22, '5 DE JULIO'),
(23, 'PLAYA VERDE'),
(24, 'LA CONCORDIA'),
(25, 'LOS BALSAMOS'),
(26, 'LAS AMAZONAS'),
(27, 'SAN MIGUEL'),
(28, 'ALFALLANO'),
(29, 'EL ROSARIO'),
(30, 'EL ZAMURO'),
(31, 'LA MORITA'),
(32, 'SANTA EDUVIRGES'),
(33, 'MINAS DE ARENA'),
(34, 'MATADERO'),
(35, 'AEROPUERTO'),
(36, 'LA AGUSTINA'),
(37, 'AUTOCONSTRUCCION I'),
(38, 'AUTOCONSTRUCCION II'),
(39, 'UNIVERSIDAD'),
(40, 'JOSE FELIX RIBAS'),
(41, 'LA REPRESA'),
(42, 'LA FLORIDA I'),
(43, 'FLORIDA II'),
(44, 'PARAISO'),
(45, 'LAS INDUSTRIAS'),
(46, 'POLIDEPORTIVO'),
(47, 'CARLOS PEREZ'),
(48, 'PUEBLO NUEVO'),
(49, 'CALLE NUEVA'),
(50, 'LA VIGIA II'),
(51, 'LA VIGIA I'),
(52, 'COCACOLA'),
(53, '12 DE OCTUBRE'),
(54, 'ROMULO GALLEGOS'),
(55, 'EL MARTILLO'),
(56, 'LA ATASCOSA '),
(57, 'CASCO CENTRAL '),
(58, 'SIMON BOLIVAR'),
(59, 'LAS GARCITAS'),
(60, 'PADRE CHACIN'),
(61, 'CORAZON DE JESUS'),
(62, 'LOS COCOS'),
(63, 'JARDIN LA PASCUA'),
(64, 'LA PUA'),
(65, 'RUIZ PINEDA'),
(66, 'LAS MARGARITAS'),
(67, 'EL FARALYON'),
(68, 'ALBORADA CONTRY'),
(69, 'VILLAS DE SOL'),
(70, 'BANCO OBRERO'),
(71, 'VIDAL GUIA I'),
(72, 'VIDAL GUIA II'),
(73, 'VIDAL GUIA III'),
(74, 'LAS CASCADA'),
(75, 'EL PARQUE'),
(76, 'TERRAZAS DEL PARQUE'),
(77, 'MORICHAL'),
(78, 'LOS BOLIVARIANOS'),
(79, 'TERRAZA DE HUGO CHAVEZ'),
(80, 'OCV LA CANDELARIA'),
(81, 'LA TRINIDAD'),
(82, 'LA GRACIA DE DIOS'),
(83, 'MARIA DE SAN JOSE'),
(84, 'PALMAR I'),
(85, 'PALMAR II'),
(86, 'PALMAR III'),
(87, 'CERRITO I'),
(88, 'CERRITO II'),
(89, 'CERRITO III'),
(90, 'RODRIGUEZ CHACIN'),
(91, 'EL REMANSO'),
(92, 'FRENTE AL AMPARO'),
(93, 'ALTO DE LOS REYES'),
(94, 'LAS CAROLINAS'),
(95, 'LOS LAURELES'),
(96, 'CRISTO REY'),
(97, 'VIPEDI'),
(98, 'LAS LOMAS'),
(99, 'LOMAS DEL LLANOS II'),
(100, 'GUAMACHAL'),
(101, 'LA ARBOLEDA'),
(102, 'TERRAZA DE COROZAL'),
(103, 'LLANO ALTO'),
(104, 'FOGONCITO'),
(105, 'LA BENDICION'),
(106, 'TAMANACO CONTRY'),
(107, 'VILLA DEL ROSARIO'),
(108, 'LA TRES GRACIAS'),
(109, 'LAS AVES'),
(110, 'LA SOLUCION'),
(111, 'TERRAZA DE EL LIDO'),
(112, 'VILLA SHALOM'),
(113, 'VILLAS DE PLATA'),
(114, 'LOS CHAGUARAMOS'),
(115, 'EL AMPARO'),
(116, 'LAS VILLAS'),
(117, 'PALMA REAL'),
(118, 'LOMAS DEL LLANOS'),
(119, 'LOMAS DEL LLANOS V'),
(120, 'CONJ. RES.GUAMACHAL MEIN'),
(121, 'CONJ. RES.GUAMACHAL 1'),
(122, 'CONJ. RES.GUAMACHAL II'),
(123, 'CONJ. VILLAS DEL VALLE'),
(124, 'VILLA CERRITO'),
(125, 'VALLE FRESCO'),
(126, 'VILLA SHARON'),
(127, 'VILLA VIRGEN DEL VALLE'),
(128, 'VILLAS LA PASCUA'),
(129, 'CONJUNTO RESIDENCIAL GUAMACHAL (ARBOLEDA)'),
(130, 'CONJUNTO RESIDENCIAL VIPEDI II'),
(131, 'CONJUNTO RESIDENCIAL PAEZ'),
(132, 'CONJUNTO RESIDENCIAL  5 DE JULIO'),
(133, 'CONJUNTO RESIDENCIAL LA FUENTE');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_us` varchar(8) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `clave` varchar(8) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `nombres` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `estado` varchar(10) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_us`, `clave`, `nombres`, `apellidos`, `estado`) VALUES
('admin', 'admin', 'Administrador', 'Administrador', 'Activo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumno`
--
ALTER TABLE `alumno`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `beneficiario`
--
ALTER TABLE `beneficiario`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estados`
--
ALTER TABLE `estados`
  ADD PRIMARY KEY (`id_estado`);

--
-- Indices de la tabla `sectores`
--
ALTER TABLE `sectores`
  ADD PRIMARY KEY (`id_sector`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alumno`
--
ALTER TABLE `alumno`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
