$(function(){
	$("#caja1").show();
	$("#caja2").hide();
	$("#caja3").hide();
	$("#caja4").hide();
	$("#caja5").hide();
	$("#caja6").hide();

    /*Inicio*/
	$('#btn1').click(function(){
		var tit = $("#btn1")
		$("#carouselExampleControls").hide();
		$("#caja1").hide();
		$("#caja2").hide();
		$("#caja3").hide();
		$("#caja4").hide();
		$("#caja5").hide();
		$("#caja6").hide();

		$("#titCon").text('Acerca de nosotros');
		$("#caja1").show();
	});

	/*Acerca de*/
	$('#btn2').click(function(){
		$("#carouselExampleControls").hide();
		$("#caja1").hide();
		$("#caja2").hide();
		$("#caja3").hide();
		$("#caja4").hide();
		$("#caja5").hide();
		$("#caja6").hide();
		
		$("#titCon").text('Acerca de nosotros');
		$("#caja2").show();
	});

    /*Servicios*/
	$('#btn3').click(function(){
		$("#carouselExampleControls").hide();
		$("#caja0").hide();
		$("#caja1").hide();
		$("#caja2").hide();
		$("#caja3").hide();
		$("#caja4").hide();
		$("#caja5").hide();
		$("#caja6").hide();
		
		$("#titCon").text('Planes');
		$("#caja1").show();
	});

    /*Productos*/
	$('#btn4').click(function(){
		$("#carouselExampleControls").hide();
		$("#caja0").hide();
		$("#caja1").hide();
		$("#caja2").hide();
		$("#caja3").hide();
		$("#caja4").hide();
		$("#caja5").hide();
		$("#caja6").hide();

		$("#titCon").text('Contacto');
		$("#caja2").show();
	});

	$('#btn5').click(function(){
		$("#caja").hide();
		$("#caja2").hide();
		$("#caja3").hide();
		$("#caja4").hide();
		$("#caja6").hide();
		
		
		$("#titCon").text('Sucursales');
		$("#caja5").show();
	});

	$('#btn6').click(function(){
		$("#caja").hide();
		$("#caja2").hide();
		$("#caja3").hide();
		$("#caja4").hide();
		$("#caja5").hide();
		
		$("#titCon").text('Contactanos');
		$("#caja6").show();
	});
})