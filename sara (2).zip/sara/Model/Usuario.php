<?php 
/**
* 
*/
class Usuario
{
	private $id;
	private $clave;
	private $nombres;
	private $apellidos;
	private $rol;
	private $estatus;
	

	
	function __construct($id, $clave, $nombres,$apellidos, $rol, $estatus)
	{
		$this->setId($id);
		$this->setClave($clave);
		$this->setNombres($nombres);
		$this->setApellidos($apellidos);
		$this->setRol($rol);		
		$this->setEstatus($estatus);
	}

	public function getId(){
		return $this->id;
	}

	public function setId($id){
		$this->id = $id;
	}

	public function getClave(){
		return $this->clave;
	}

	public function setClave($clave){
		$this->clave = $clave;
	}

	public function getNombres(){
		return $this->nombres;
	}

	public function setNombres($nombres){
		$this->nombres = $nombres;
	}

	public function getApellidos(){
		return $this->apellidos;
	}

	public function setApellidos($apellidos){
		$this->apellidos = $apellidos;
	}
	public function getRol(){
		return $this->rol;
	}

	public function setRol($rol){
		$this->rol = $rol;
	}

	public function getEstatus(){
		return $this->estatus;
	}	

	public function setEstatus($estatus){
		$this->estatus = $estatus;
	}

	public static function save($Usuario){
		$db=Db::getConnect();
		//var_dump($alumno);
		//die();
		

		$insert=$db->prepare('INSERT INTO usuario VALUES (:id, :clave :nombres,:apellidos,:rol,:estatus)');
		$insert->bindValue('id',$Usuario->getId());
		$insert->bindValue('id',$Usuario->getClave());
		$insert->bindValue('nombres',$Usuario->getNombres());
		$insert->bindValue('apellidos',$Usuario->getApellidos());
		$insert->bindValue('rol',$Usuario->getRol());
		$insert->bindValue('estatus',$Usuario->getEstatus());
		$insert->execute();
	}

	public static function all(){
		$db=Db::getConnect();
		$listaUsuarios=[];

		$select=$db->query('SELECT * FROM usuario order by id_usua');

		foreach($select->fetchAll() as $usuario){
			$listaUsuarios[]=new Usuario($usuario['id_usua'],$usuario['clave_usua'],$usuario['nomb_usua'],$usuario['apell_usua'],$usuario['rol_usua'],$usuario['estat_usua']);
		}
		return $listaUsuarios;
	}

	public static function searchById($id){
		$db=Db::getConnect();
		$select=$db->prepare('SELECT * FROM usuario WHERE id_usua=:id');
		$select->bindValue('id',$id);
		$select->execute();

		$usuarioDb=$select->fetch();

		if (!empty($usuarioDb['id_usua'])) {
			$usuario = new Usuario ($usuarioDb['id_usua'],$usuarioDb['clave_usua'],$usuarioDb['nomb_usua'],$usuarioDb['apell_usua'],$usuarioDb['rol_usua'],$usuarioDb['estat_usua']);
			//echo "Epa.. ". var_dump($usuarioDb)."epa2";
			//var_dump($usuario);
			//die();
			
		} else {
			$usuario = new Usuario("","","","","","");
			
		}
        return $usuario;
	}

	public static function update($Usuario){
		$db=Db::getConnect();
		$update=$db->prepare('UPDATE usuario SET clave_usua=:clave nomb_usua=:nombres, apell_usua=:apellidos, rol_usua=:rol, estat_usua=:estatus WHERE id_usua=:id');
		$update->bindValue('clave', $Usuario->getClave());
		$update->bindValue('nombres', $Usuario->getNombres());
		$update->bindValue('apellidos',$Usuario->getApellidos());
		$update->bindValue('rol',$Usuario->getRol());
		$update->bindValue('estatus',$Usuario->getEstatus());
		$update->bindValue('id',$Usuario->getId());
		$update->execute();
	}

	public static function delete($id){
		$db=Db::getConnect();
		$delete=$db->prepare('DELETE  FROM usuario WHERE id_usua=:id');
		$delete->bindValue('id',$id);
		$delete->execute();		
	}
}

?>